function [X, n, Sigma2] = MyPro2TraceNorm(Z, tau)
 % % % % % % % % % M{i} = Fold(MyPro2TraceNorm(tempt_g,tau),dim,i);


[m, n] = size(Z);    % 476 * 2250 时
if 2*m < n     % 代表（unfolding之后的）矩阵是非常矮胖的
    AAT = Z*Z';
    [S, Sigma2, D] = svd(AAT);  % Sigma2: 476 * 476
    Sigma2 = diag(Sigma2);    % 提取方阵的对角线元素，结果为列向量    
    V = sqrt(Sigma2);    % V: 476 * 1
%     size_V = size(V)
    tol = max(size(Z)) * eps(max(V));  % 1*1的实数， tol的值很小
    
    temp_tol_tal = max(tol, tau);  % tau : 476*1 ?
%     size_tau = size(tau)
%     size_temp_tol_tal = size(temp_tol_tal)  

    n = sum(V > max(tol, tau));
    
%     max_V_1 = max(V(:))
    mid = max(V(1:n)-tau(1:n), 0) ./ V(1:n) ;
    X = S(:, 1:n) * diag(mid) * S(:, 1:n)' * Z;
    return;
end
if m > 2*n
    [X, n, Sigma2] = MyPro2TraceNorm(Z', tau);
    X = X';
    return;
end
[S,V,D] = svd(Z);
Sigma2 = diag(V).^2;
n = sum(diag(V) > tau);
% max_V_2 = max(V(:))
% max_tau_2 = max(tau(:))
X = S(:, 1:n) * max(V(1:n,1:n)-diag(tau(1:n)), 0) * D(:, 1:n)';




