clear all
close all
clc

addpath(genpath(pwd));
%% ground truth
data=double(imread('o_air.png')); %% color images
% load('CThead.mat');%% MRI data 
% load('biking.mat') %% video data
dim=size(data);
normdata=norm(data(:));
s1='%20s\t%8s\t%8s\t%12s\n';
fprintf(s1,'observed percent','PSNR','RSE','time cost');
%% initialization
max_Iter=500;
epsilon=1e-3;
% p=0.1:0.1:0.9;%sampling rate
p=0.4:0.1:0.9; %SR for color image
cons=1000;
stepsize=3;
patchsize=3;
lambda=1.5;
for j=1:length(p)
    file=[num2str(p(j)),'chosen_airplane','.mat']; %% load the incomplete data
    load(file)   
    X=data;
    X(:) = mean(data(chosen));
    X(chosen) = data(chosen);
    beta=1e-6;    
    %% Initialization of C^(0) and D^(0)
    patchData  = im2colstep(X, [patchsize,patchsize,patchsize],[stepsize,stepsize,stepsize]);
    D = DctInit(patchsize);
    C = wthresh(D'*patchData, 'h',sqrt(2*lambda/beta));    
    Y=cell(1,3);Y{1,1}=0;Y{1,2}=0;Y{1,3}=0;
    G=cell(1,3);G{1,1}=0;G{1,2}=0;G{1,3}=0;
    alpha=[1/3 1/3 1/3];
    epsilon2=1e-16;
    W=cell(1,3);
    history_error=zeros(max_Iter,1);
    Gsum = zeros(dim);
    Ysum = zeros(dim);
    X_original=data;
    X_original(chosen)=[];
    tic
    for k=1:max_Iter
        beta=beta*1.05;
        Gsum = 0*Gsum;
        Ysum = 0*Ysum;
        %% compute X^(k+1)
        temp=zeros(dim);
        for i=1:3
            Gsum=Gsum+G{i};
            Ysum=Ysum+Y{i};
        end
        AA=col2imstep(D*C,dim,[patchsize,patchsize,patchsize],[stepsize,stepsize,stepsize]);
        X_history=X;
        X=(-Ysum+ beta*(Gsum+AA)) / ((ndims(data)+1)*beta);
        X(chosen)=data(chosen);
        %% stopping criterion for iteration
        history_error(k)=norm(X_history(:)-X(:))/normdata;
        if (k>70&&history_error(k) < epsilon)
            break;
        end
        %% update weights
        for i=1:3
            temp1=Unfold(X,dim, i);[tempS,tempV,tempD]=MySVD(temp1);
            W{i}=cons./(diag(tempV)+epsilon2);
        end
        %% compute G_i^(k+1)
        for i=1:3
            tau=alpha(i)/beta*W{i};
            temp1=Unfold((X+Y{i}/beta),dim, i);
            G{i}=Fold(MyPro2TraceNorm(temp1,tau), dim, i);
        end
        %% compute C^(k+1)
        patchData  = im2colstep(X, [patchsize,patchsize,patchsize],[stepsize,stepsize,stepsize]);
        C = wthresh(D'*patchData, 'h', sqrt(2*lambda/beta));
        %% compute D^(k+1)
        [DU, DS, DV] = svd(patchData*C',0);
        D= DU*DV';
        %% compute Y_i^(k+1)
        for i=1:3
            Y{i}=Y{i}+beta*(X-G{i});
        end
    end
    errList= history_error(1:k);
    t=toc;
    %% compute PSNR and RSE
    XX=X;
    XX(chosen)=[];
    X_dif=X_original-XX;
    RSE=20*log10(norm(X_dif(:))/norm(data(:)));
    MSE=(norm(X_dif(:))^2)/(prod(dim));
    PSNR=10*log10(255^2/MSE);
    s2='%13.1f\t%17.2f\t%9.2f\t%10.2f\n';
    fprintf(s2,p(j),PSNR,RSE,t);
end

