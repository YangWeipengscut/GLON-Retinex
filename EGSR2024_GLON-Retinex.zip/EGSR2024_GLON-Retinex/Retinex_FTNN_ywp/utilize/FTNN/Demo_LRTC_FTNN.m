%% =================================================================
% This script compares low-rank tensor completion methods
% listed as follows:
%     1. FTNN         Framelet representation of tensor nuclear norm  for third order tensor completion
%
% More detail can be found in [1]
% [1] Tai-Xiang Jiang, Michael K. Ng, Xi-Le Zhao, and Ting-Zhu Huang.
%     Framelet Representation of Tensor Nuclear Norm for Third-Order Tensor
%     Completion. IEEE Transactions on Image Processing. Volume 29, 2020.
%
% Created by Tai-Xiang Jiang (taixiangjiang@gmail.com)
% 08/27/2020

%% =================================================================
% clc;
clear;
close all;
addpath(genpath('lib'));
addpath(genpath('data'));

%% Set enable bits
EN_FTNN       = 1;
methodname    = {'Observed' ,'FTNN'};
Mnum = length(methodname);
Re_tensor  =  cell(Mnum,1);
MPSNRALL       =  zeros(Mnum,1);
SSIMALL       =  zeros(Mnum,1);
FSIMALL       =  zeros(Mnum,1);
time       =  zeros(Mnum,1);

%% Load initial data
for   data_num = 1
    switch data_num
        case 1
            load foreman.mat
            X = X(:,:,1:100);
            data_name = 'V_fore';
    end
    [n1,n2,n3] = size(X);
    for i=1:n3
        temp=X(:,:,i);
        X(:,:,i)=temp/max(temp(:));
    end
    
    %% Sampling with random position
    sample_ratio = 0.3;
    fprintf('\n');
    fprintf('===========data no. %d=====Results=p=%f======================\n',data_num,sample_ratio);
    
    Y_tensorT   = X;
    Ndim        = ndims(Y_tensorT);
    Nway        = size(Y_tensorT);
    Omega       = find(rand(prod(Nway),1)<sample_ratio);
    Ind         = zeros(size(X));
    Ind(Omega)  = 1;
    Y_tensor0   = zeros(Nway);
    Y_tensor0(Omega) = Y_tensorT(Omega);
    %%
    i  = 1;
    Re_tensor{i} = Y_tensor0;
    [MPSNRALL(i), SSIMALL(i), FSIMALL(i)] = quality(Y_tensorT*255, Re_tensor{i}*255);
    time(i) = 0;
    enList = 1;
    fprintf(' %8.8s    %5.4s    %5.4s    %5.4s   %5.4s   %5.4s \n','method','PSNR', 'SSIM', 'FSIM','iter','time');
    fprintf(' %8.8s    %5.3f    %5.3f    %5.3f    %3.3d     %.1f \n',...
        methodname{enList(i)},MPSNRALL(enList(i)), SSIMALL(enList(i)), FSIMALL(enList(i)),0,time(i));
    %% Perform  algorithm
    
    
    %% Use FTNN
    i = i+1;
    if EN_FTNN
        enList = [enList,i];
        %parameters
        opts.Frame    = 1; % (0,1,3)
        opts.Level    = 4;  % [1,2,3,4,5,6]
        opts.wLevel   = -1;
        opts.lambda1  = 1;
        opts.beta     = 1;
        opts.tol      = 1e-2;
        opts.rho      = 1;
        opts.DEBUG    = 0;
        opts.max_iter = 100;
        opts.max_beta = 1e10;
        
        tStart = tic;
        [Xhat3_out,obj,~,iter] = LRTC_FL(Y_tensor0,Omega,opts,X);
        Re_tensor{i} = Xhat3_out;
        time(i)= toc(tStart);
        [MPSNRALL(i), SSIMALL(i), FSIMALL(i)] = quality(Y_tensorT*255, Re_tensor{i}*255);
        fprintf(' %8.8s    %5.3f    %5.3f    %5.3f    %3.3d   %.1f | Frame =  %d, Level = %d, beta = %.2f\n',...
            methodname{i},MPSNRALL(i), SSIMALL(i), FSIMALL(i),iter,time(i),...
            opts.Frame,opts.Level,opts.beta);
        
        
    end
end

