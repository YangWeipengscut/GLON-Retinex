
%% 图像维度的转换:shiftdim函数

clear; clc; close all

addpath(genpath("data"))

Img_ori = imread('01.jpg');


Img_shift_1 = shiftdim(Img_ori, 1);

Img_shift_2 = shiftdim(Img_shift_1, 2);

figure,
subplot(121),imshow(Img_ori),title("Ori");
subplot(122),imshow(Img_shift_2),title("shift2");

mse_value = mse(Img_ori,Img_shift_2)
err_value = Img_ori-Img_shift_2;
max(err_value(:))
min(err_value(:))
