clear; close all;clc;
addpath(genpath('utilize'))


param.stepsize = 3;
param.patchsize = 3;

%% FTNN参数
param.Frame = 3;
param.Level = 4;
param.WLevel = -1;
param.thresh = 1; % thresh对应FTNN论文中的lambda1
param.rho    = 1.2; % FTNN论文中的rho=1
param.max_beta = 1e10;

% case_n 参数设置
param.max_iter = 8;   
param.lambda_1 = 0.001;   % base: 0.002
param.lambda_2 = 0.001;   % base: 0.005 
param.beta  = 0.001;
case_name = '_case_4';
% case_name = '_test';

% case_31_iter6参数设置
% param.max_iter = 6;
% param.lambda_1 = 0.005;   % case31_iter12
% param.lambda_2 = 0.0061;   % case31_iter12
% param.beta  = 0.003;       % case31_iter12
% case_name = '_case_31_iter6';

dataset = 1;
% 1 : LOL-v1
% 2 : LOL-v2
% 3 : PG660
% 4 : PG660_50
switch dataset
    case 1
        gamma = 2.6;
        path = 'data/LOL-v1/low/';
        outputDir=['Results_FTNN_Retinex_LOL_v1_2.6', case_name, '/'];
        files = dir([path '*.png']);
    case 2
        gamma = 2.6;
        path = 'data/LOL-v2/Real_captured/Test/Low/';
        outputDir=['Results_FTNN_Retinex_LOL_v2_2.6', case_name , '/'];
        files = dir([path '*.png']);
    case 3
        gamma = 2.2;
        path = 'data/PG660_660/';
        outputDir=['Results_FTNN_Retinex_PG660_2.2', case_name , '/'];
        files = dir([path '*.jpg']);
    case 4
        gamma = 2.2;
        path = 'data/MixPG660_50/';
        outputDir=['Results_FTNN_Retinex_PG660_50_2.2', case_name , '/'];
        files = dir([path '*.jpg']);
end


im_num = length(files);
time_ours = zeros(im_num,1);


methodname = 'FTNN_';


if ~exist(outputDir, 'dir')
    mkdir(outputDir)
end


for i_th = 1:length(files)
    time_start = tic;
    fprintf('The %d-th Image of %d \n' , i_th, length(files) )
    imgname = files(i_th).name;
    Input_img = im2double(imread([path imgname]));

    [L, R] = Ftnn_Retinex(Input_img, param);

    for k_cha = 1:3
        L(:,:,k_cha) = min(max(L(:,:,k_cha),0),max(max(L(:,:,k_cha))));
        R(:,:,k_cha) = min(max(R(:,:,k_cha),0),max(max(R(:,:,k_cha))));
    end
    
    L_hsv = rgb2hsv(L);
%%%%%%%%
%     temp_max = max(L_hsv(:))
%     dim_hsv = size(L_hsv);
%     L_hsv_gamma = zeros(dim_hsv(1),dim_hsv(2));
%     for i = 1:dim_hsv(1)
%         for j = 1:dim_hsv(2)
%             if L_hsv(i,j,3) <= 0.8*temp_max
%                 L_hsv_gamma(i, j) = L_hsv(i,j,3).^(1/3);
%             else
%                 L_hsv_gamma(i, j) = L_hsv(i,j,3).^(1/2.2);
%             end
%         end
%     end

%%%%%%%%%%%%%


    L_hsv_gamma = L_hsv(:,:,3).^(1/gamma);
    L_hsv(:,:,3) = L_hsv_gamma;
    L_rgb = hsv2rgb(L_hsv);
    res = R.*L_rgb;
%     res = R_DC.*L_rgb;
    
    time_ours(i_th,1) = toc(time_start);

    name_split = split(imgname,'.');
%     imwrite(res,[outputDir 'Rec/' name_split{1} '.png']); 
    imwrite(res,[outputDir name_split{1} '.png']); 
    imwrite(L  ,[outputDir 'L_'   name_split{1}  '_gamma_',num2str(gamma) methodname case_name '.png']); 
    imwrite(R  ,[outputDir 'R_'   name_split{1}  '_gamma_',num2str(gamma) methodname case_name '.png']); 
   
end

% save(['C:\PG2023_Code\Results_Ours_LOL-v1_base\',time_ours])
save([outputDir,'time.mat'],'time_ours')





