function L_my = solve_L_BT(Input_img_RGB_dila,  L_0,   P1_RGB_0,    opts_my, sigma_iter)
%        L =    solve_L_BT(Input_img_RGB_dila,  L_0,   P1_RGB_0, opts_my,sigma_iter);

phi = opts_my.lambda_1;
rho_1 = opts_my.rho_1;
R = P1_RGB_0;

sharpness = 0.02;
[wx, wy] = computeTextureWeights(L_0, sigma_iter, sharpness);
L_my = solveLinearEquation(Input_img_RGB_dila,R, wx, wy, phi, rho_1, L_0);
end


function [retx, rety] = computeTextureWeights(fin, sigma,sharpness)
   %% Bx、By
   %% 
   fx = diff(fin,1,2);   
   fx = padarray(fx, [0 1 0], 'post');
   fy = diff(fin,1,1);
   fy = padarray(fy, [1 0 0], 'post');
   vareps_s = sharpness;
   vareps = 0.00001;
%    vareps = 0.00001;
   wto = max(sum(sqrt(fx.^2+fy.^2),3)/size(fin,3),vareps_s).^(-1);   
%    fbin = lpfilter(fin, sigma);   
   
   %%
   kszie = bitor(round(5*sigma),1);
   f_g_s = fspecial('gaussian',kszie,sigma);

   dimX = size(fin,1);
   dimY = size(fin,2);
   c = size(fin,3);
   
    %% method 1, G 
    %     kszie_r = 2 * (kszie/2-1) + 1;
    %     sigma_r = 2;
    %     f_G = fspecial('gaussian',kszie_r,sigma_r);
    %     G   = fbin;  %  
    %% method 2, G
    B = zeros(size(fin));
    mRTVs = zeros(size(fin));
    for i = 1:c
        [B(:,:,c), mRTVs(:,:,c)] = computeBlurAndMRTV(fin(:,:,c), floor(kszie/2));
    end
    mRTV = sum(mRTVs,3) / c;
    G = computeGuidance(B, mRTV, floor(kszie/2));

   kszie_r = 2 * (kszie/2-1) + 1;
   half_kszie_r = floor(kszie_r / 2);
   sigma_r = 2;
   parfor i = 1:dimX
       for j = 1:dimY
           for cha = 1:c
               minX = max(i - half_kszie_r ,1);
               maxX = min(i + half_kszie_r,dimX);

               minY = max(j - half_kszie_r ,1);
               maxY = min(j + half_kszie_r,dimY);

               % guidance map
               G_patch = G(minX:maxX,minY:maxY,cha);
               f_r     = exp(-(G_patch - G(i,j,cha).^2) / (2*sigma_r^2));
               f_sr    = f_r .* f_g_s((minX:maxX)-i + half_kszie_r + 1,(minY:maxY) - j + half_kszie_r +1);

               fbin_patch = fin(minX:maxX,minY:maxY,cha);
               JBLs(i,j,cha) = sum(fbin_patch(:).*f_sr(:))/sum(f_sr(:));
           end
       end
   end


   JBL = sum(JBLs,3)/c;
   B_x = abs(diff(JBL,1,2));
   B_x = padarray(B_x, [0 1 0], 'post');
   wtbx = max(B_x,vareps).^(-1); 

   B_y = abs(diff(JBL,1,1));
   B_y = padarray(B_y, [1 0 0], 'post');
   wtby = max(B_y,vareps).^(-1);
   
   B_x = max(B_x,vareps); 
   B_y = max(B_y,vareps);
   B_xy = sqrt(B_x.^2 + B_y.^2);

%    figure('Name','windowed bilateral variation'),imshow(B_xy,[]);
   

%    wtbx = max(sum(abs(gfx),3)/size(fin,3),vareps).^(-1); 
%    wtby = max(sum(abs(gfy),3)/size(fin,3),vareps).^(-1);   
   retx = wtbx.*wto;
   rety = wtby.*wto;
   retx(:,end) = 0;
   rety(end,:) = 0;      
end


function ret = conv2_sep(im, sigma)
  ksize = bitor(round(5*sigma),1);
  g = fspecial('gaussian', [1,ksize], sigma); 
  ret = conv2(im,g,'same');
  ret = conv2(ret,g','same');  
end

function FBImg = lpfilter(FImg, sigma)     
    FBImg = FImg;
    for ic = 1:size(FBImg,3)
        FBImg(:,:,ic) = conv2_sep(FImg(:,:,ic), sigma);
    end   
end

function OUT = solveLinearEquation(I_lowlight, R, wx, wy, phi, rho_1, L_pre)

    [row,col,ch] = size(I_lowlight);
    dim_xy = row * col;
    e = wx(:);
    w = padarray(e, row, 'pre'); w = w(1:end-row);
    s = wy(:);
    n = padarray(s, 1, 'pre'); n = n(1:end-1);
    D = e + w + s + n;
    T = spdiags([-e, -s],[-row,-1],dim_xy,dim_xy);
    %% 
    MN = T + T' + spdiags(D, 0, dim_xy, dim_xy);

    OUT = I_lowlight;

    for ii=1:ch
               
        %% 左边
        R_cha = R(:,:,ii);
        R_cha_2 = R_cha.^2;
        R_cha_2 = spdiags(R_cha_2(:),0,dim_xy,dim_xy);
        DEN = R_cha_2 + phi * MN + (rho_1/2)*speye(dim_xy,dim_xy);
        
        % 右边
%         size_1 = size(I_lowlight)
%         size_2 = size(R_cha)
%         size_3 = size(L_pre)

        right_yr = I_lowlight(:,:,ii).* R_cha + (rho_1/2)*L_pre(:,:,ii);

        L_ichol = ichol(DEN,struct('michol','on'));
        [tout, ~] = pcg(DEN, right_yr(:),0.1,100, L_ichol, L_ichol'); 
        OUT(:,:,ii) = reshape(tout, row, col);
    end 
        
end
