function [L, R] = Ftnn_Retinex(Input_img, para)

% set parameters

if ~exist('para', 'var')
    para = [];
end
if isfield(para, 'Frame'); Frame = para.Frame; end
if isfield(para, 'Level'); Level = para.Level; end
if isfield(para, 'WLevel'); WLevel = para.WLevel; end
if isfield(para, 'beta') ; beta  = para.beta;  end
if isfield(para, 'thresh');thresh= para.thresh;end
if isfield(para, 'rho')  ; rho   = para.rho;   end
if isfield(para, 'max_iter'); max_iter = para.max_iter; end
if isfield(para, 'max_beta'); max_beta = para.max_beta; end
if isfield(para, 'lambda_1'); lambda_1 = para.lambda_1; end
if isfield(para, 'lambda_2'); lambda_2 = para.lambda_2; end

dim         = size(Input_img);

%% 1. initialize variables
L       = Input_img;
R       = ones(dim);
% R       = randn(dim);

% randn

errR = zeros(max_iter,1);
errL = zeros(max_iter,1);

sigma = 3.0;      
sigma_iter = sigma;
dec=2;



%% 要维度sihft
R_shift = shiftdim(R, 1);
dim_R_shift = size(R_shift);    

% D_W Level Frame
[D_W, RR_W_T] = GenerateFrameletFilter(Frame);
R_shift_W = Fold( FraDecMultiLevel(Unfold(R_shift, size(R_shift), 3), D_W, Level) ,  ...
    [dim_R_shift(1:2), dim_R_shift(3)*size(D_W,1)*Level], 3);
V = R_shift_W;
Multiplier = zeros(size(R_shift_W));

nfilter   = 1;
nD        = size(D_W, 1);  % 3
muLevel   = ones(size(R_shift_W));
len       = dim_R_shift(3); %  n1
if WLevel<=0     % wLevel = -1
    for ki=1:Level    % Level = 4
        for ii=1:nD   % nD   = 3   len = n3
            muLevel(:,:,len*(ki-1)*nD+(ii-1)*len+1: len*(ki-1)*nD+ii*len)= muLevel(:,:,len*(ki-1)*nD+(ii-1)*len+1: len*(ki-1)*nD+ii*len)*nfilter*norm(D_W(ii,:));
        end
        nfilter = nfilter*norm(D_W(ii,:));
    end
else
    for ki=1:Level
        for ii=1:nD-1
            muLevel(:,:,len*(ki-1)*nD+(ii-1)*len+1: len*(ki-1)*nD+ii*len)=muLevel(:,:,len*(ki-1)*nD+(ii-1)*len+1: len*(ki-1)*nD+ii*len)*nfilter;
        end
        nfilter = nfilter*wLevel;
    end
end


%% 3. main loop
vareps = 0.001;
iter = 1;
while(iter<=max_iter)    

    if iter == 1
        R_old = randn(size(R));

    else
        R_old = R;
    end
    L_old = L;
    V_old = V;

%     Input_img = Input_img + 0.1*(Input_img - L.*R);

    %% V
    Nu1 = R_shift_W + Multiplier/beta;
    nn  = zeros(size(R_shift_W, 3), 1);
    for k = 1:size(R_shift_W,3)
        [V(:,:,k),nn(k)] = prox_nuclear(Nu1(:,:,k), muLevel(1,1,k)*thresh*lambda_2/beta); % thresh对应FTNN论文中的lambda1
%         [V(:,:,k),nn(k)] = prox_nuclear(Nu1(:,:,k), thresh*lambda_2/beta); % thresh对应FTNN论文中的lambda1
    end

    %% 2) update R
    % 先得到R_shift，再得到R

    % 将输入图像和照度分量进行维度移动, 维度移动后的维度为： n2 * 3 *n1
    Input_img_shift = shiftdim(Input_img, 1);
    L_shift = shiftdim(L, 1);
    % 将维度移动后的Input_img_shift和L_shift按mode-3展开
    Input_img_shift_unfold3 = Unfold(Input_img_shift, size(Input_img_shift), 3);
    L_shift_unfold3         = Unfold(L_shift, size(L_shift), 3);

    % 方程右边
    Nu2 = V - Multiplier/beta;
    temp_1 = Input_img_shift_unfold3 .* L_shift_unfold3;
    temp_2 = (beta/2)*FraRecMultiLevel( Unfold(Nu2, size(Nu2), 3) , RR_W_T, Level);
    temp = temp_1 + temp_2;  % 截至上一行，temp还是矩阵形式： n1*(3*n2)
    temp_vector = temp(:);   % 展开为列向量形式

    % 方程的左边
    % 创建L_shift组成的对角矩阵
    L_shift_unfold3_up_2 = L_shift_unfold3.^2 + (beta/2)*1; % 1对应推导公式中的单位矩阵
    [height_L3, weight_L3] = size(L_shift_unfold3_up_2);
    HW = height_L3 * weight_L3;
    L_shift_unfold3_up_2_diag = spdiags(L_shift_unfold3_up_2(:), 0, HW, HW);

    % 求解线性方程组
    linear_method = 'pcg';
    switch linear_method
        case 'pcg'
            IC_M = ichol(L_shift_unfold3_up_2_diag, struct('michol','on')); %  IC_M: ichol matrix
            [dst, ~] = pcg(L_shift_unfold3_up_2_diag, temp_vector, 0.01,40, IC_M, IC_M');
        case 'minres'
            [dst, ~] = minres(L_shift_unfold3_up_2_diag, temp_vector, 0.01, 40);
    end  % 得到的dst为R_shift_unfold3的列向量
    
    R_shift_unfold3 = reshape(dst, height_L3, weight_L3);
    R_shift = Fold(R_shift_unfold3, dim_R_shift, 3);    
    R = shiftdim(R_shift, 2);

    R_shift_W = Fold( FraDecMultiLevel(Unfold(R_shift, size(R_shift), 3), D_W, Level) ,  ...
    [dim_R_shift(1:2), dim_R_shift(3)*size(D_W,1)*Level], 3);   % R_shift_W : 用于更新V

   
    %% 2) update L   
    % left side
%     sigma_iter =3;
%     dec = 2;
    L =    solve_L_BT(Input_img,L_old,R,lambda_1,sigma_iter);
    sigma_iter = sigma_iter / dec;
    if sigma_iter < 0.5
        sigma_iter = 0.5;
    end

    %% Update multiplier
    Multiplier = Multiplier + beta*(R_shift_W - V);
    beta = min(rho*beta,max_beta);

    %% 收敛判断
    errR(iter) = norm(R(:)-R_old(:))/norm(R_old(:));
    errL(iter) = norm(L(:)-L_old(:))/norm(L_old(:));
    fprintf('Iteration%3g: errL: %2.4e, errR: %2.4e\n', iter, errL(iter), errR(iter));
    
    if(errR(iter)<vareps||errL(iter)<vareps)
        break;
    end

    iter = iter+1;

end
% R_undenoise = R;

% figure,plot(1:iter-1,errR(1:iter-1,1));
% hold on
% plot(1:iter-1,errL(1:iter-1,1)), legend('error of R','error of L');

end

