function [L, R_RGB] = BT_TT_L_NL_solve(Input_img_RGB_dila, Nway_VDT, nway_dila, opts_my,opt_factor,factor_nway)

Input_img_RGB_dila = double(Input_img_RGB_dila);

%% 模型参数的初始化
maxit = opts_my.maxit;
tol = opts_my.tol;

% rho
rho_1 = opts_my.rho_1;
rho_2 = opts_my.rho_2;
rho_3 = opts_my.rho_3;
rho_4 = opts_my.rho_4;
rho_5 = opts_my.rho_5;
rho_6 = opts_my.rho_6;

% lambda
lambda_1 = opts_my.lambda_1;
lambda_2 = opts_my.lambda_2;
lambda_3 = opts_my.lambda_3;
lambda_4 = opts_my.lambda_4;

% Plug-and-play (FFDnet和CBM3D)中的参数
sigma_2 = opts_my.sigma_2;

% 辅助变量P、P1相关的正则化参数
beta = opts_my.beta;
beta_1 = opts_my.beta_1;


% Tensor train rank 的权重

alpha = weightTC(Nway_VDT);
opts_my.alpha = alpha;

%% 
N = length(Nway_VDT);  % N: VDT后高维张量的维度


%% 待求解变量的初始化
% 1) (Xi, Yi)的初始化
seq_len = opt_factor.length_factor_1;
ranktube = ranktube_ywp(seq_len);
[X,Y] = initialMatrix(N,Nway_VDT,ranktube);
save X.mat X
save Y.mat Y
X0 = X; 
Y0 = Y;
X = cell(1,N-1); 
Y = cell(1,N-1);


% 2) R和P、P1的初始化
% R = initialization_M(Nway_VDT,);   % GLON paper
R = ones(Nway_VDT);   % 本子函数中的R的维度始终为VDT后的高维张量; 对应公式推导中的R^(T+1);
R0 = R;     % reshape后得到R^t (R_Temp: R^t的矩阵展开形式)

R_RGB = vdt2image_ywp(R0, factor_nway, nway_dila, opt_factor);
[w,h,c] = size(R_RGB);
P  = R_RGB;    % P同时作为P^(t)和P^(t+1)
P1 = R_RGB;    

% 3) 照度分量L的初始化
L = Input_img_RGB_dila;



%% canonical matricization
% 计算第k个模式展开下的矩阵维度
dimL = zeros(1,N-1);
dimR = zeros(1,N-1);
IL = 1;
for k = 1:N-1
    dimL(k) = IL*Nway_VDT(k);
    dimR(k) = prod(Nway_VDT)/dimL(k);
    IL = dimL(k);
end

%% rannk
max_rank = [30 50 50 30];
rank_inc = 5;

% for i=1:4
for i=1:3
    MM{i}=reshape(X0{i+2}*Y0{i+2},Nway_VDT); 
    MMi = MM{i};
    resrank{i}=norm(R0(:)- MMi(:));
end


%% 求解L的参数的初始化
sigma_L = 3.0;      
sigma_iter = sigma_L;
dec=2;



%% 迭代初始化
k = 1;
relerr = [];
relerr(1) = 1;
relerr2 = [];
Da = [];





%% 迭代求解
while relerr(k) > tol
    k = k + 1
    R_RGB_last = R_RGB;
    L_RGB_old = L;
    
    %% 1) Update (Xi, Yi)
    for n = 1:N-1
        R_Temp = reshape(R0,[dimL(n), dimR(n)]);
        X{n} = ( lambda_2*alpha(n)*R_Temp*Y0{n}' + rho_3*X0{n} )...
            * pinv( lambda_2*alpha(n)*Y0{n}*Y0{n}' + rho_3*eye( size(Y0{n}*Y0{n}') ) );
        Y{n} = pinv( lambda_2*alpha(n)*X{n}'*X{n} + rho_4*eye( size(X{n}'*X{n}) ) )...
            * ( lambda_2*alpha(n)*X{n}'*R_Temp + rho_4*Y0{n} );
    end
    
    %% 2) Update P : CBM3D
    Input_CBM3D = (beta*R_RGB + rho_6*P) / (beta + rho_6);
    B = zeros(1,c);
    for i= 1:c
        Temp2 = Input_CBM3D(:,:,i);
        B(i) = max(Temp2(:));
        Input_CBM3D(:,:,i) =  Temp2/B(i);
    end
    
    max_in2 = max(Input_CBM3D(:));min_in2 = min(Input_CBM3D(:));
    Input_CBM3D = (Input_CBM3D-min_in2)/(max_in2-min_in2);
    sigma_2_normli = sigma_2/(max_in2-min_in2);
    
    [~, P] = CBM3D(1, Input_CBM3D, sigma_2_normli);  
               
    P(P<0)=0;P(P>1)=1;
    P = P*(max_in2-min_in2)+min_in2;  
               
    for i= 1:c
        P(:,:,i) =   B(i)*P(:,:,i);
    end
    
    
    %% 3) Update P1 ： 采用PCG的方法，而不是伪逆的方法求解：
    % 方程的右边
    temp_P_right = 2*L.*Input_img_RGB_dila + beta_1*R_RGB + rho_5 * P1;
    
    % 方程的左边
    L_square = 2*L.^2;
    L_square_diag = spdiags(L_square(:), 0, h*w*c,h*w*c);
    temp_P_left = L_square_diag + (beta_1 + rho_5)*speye( h*w*c,  h*w*c);
    
    
    linear_method = 'pcg';
    switch linear_method
        case 'pcg'
            IC_M = ichol(temp_P_left, struct('michol','on')); %  IC_M: ichol matrix
            [dst, ~] = pcg(temp_P_left, temp_P_right(:), 0.01,40, IC_M, IC_M');
        case 'minres'
            [dst, ~] = minres(temp_P_left, temp_P_right(:), 0.01, 40);
    end 
    
    P1 = reshape(dst, w, h, c);
%     P1 = reshape(dst, h, w, c);  %% ???
    
    
    %% 4) Update (R, epsilon, J)
    [R_RGB,relerr] = Reinex_GLON_R_solve(R0, X,Y,P,P1,nway_dila,Nway_VDT,N,opts_my,opt_factor,factor_nway);
    
    % R_RGB要不要更新，类比GLON论文中的Mimg。
    % R_RGB = vdt2image_ywp(R, factor_nway, nway_dila, opt_factor);
    
    %% 5) Update L
    
    L =    solve_L_BT(Input_img_RGB_dila,L_RGB_old,P1, opts_my,sigma_iter);
    sigma_iter = sigma_iter / dec;
    if sigma_iter < 0.5
        sigma_iter = 0.5;
    end    
    
    
    %% 更新已经求解的变量，作为变量在第t次迭代中的值，以便在第t+1次迭代使用
    % 1) 更新(X0, Y0)
    X0 = X;
    Y0 = Y;


    [R, ~, ~] = image2vdt256_ywp(R_RGB_last, opt_factor);
    R0 = R;

    relerr(k) = abs(norm(R_RGB(:)-R_RGB_last(:)) / norm(R_RGB_last(:)));
    relerr2(k) = abs(norm(R_RGB(:)-R_RGB_last(:)) );
    Da = R;

    

    
    
    
    %% 迭代停止的准则的判断 (Judgment of iteration stop criteria)
    if k > maxit ||  relerr(k) < tol  
        break 
    end

    if k == 25
        opts_my.rho_1 = 1.5* opts_my.rho_1;
        opts_my.rho_2 = 1.5* opts_my.rho_2;
        opts_my.rho_3 = 1.5* opts_my.rho_3;
        opts_my.rho_4 = 1.5* opts_my.rho_4;
        opts_my.rho_5 = 1.5* opts_my.rho_5;
        opts_my.rho_6 = 1.5* opts_my.rho_6;
        rho_1 = opts_my.rho_1;
        rho_2 = opts_my.rho_2;
        rho_3 = opts_my.rho_3;
        rho_4 = opts_my.rho_4;
        rho_5 = opts_my.rho_5;
        rho_6 = opts_my.rho_6;
    end
    
    if k == 30
        opts_my.rho_1 = 1.5* opts_my.rho_1;
        opts_my.rho_2 = 1.5* opts_my.rho_2;
        opts_my.rho_3 = 1.5* opts_my.rho_3;
        opts_my.rho_4 = 1.5* opts_my.rho_4;
        opts_my.rho_5 = 1.5* opts_my.rho_5;
        opts_my.rho_6 = 1.5* opts_my.rho_6;
        rho_1 = opts_my.rho_1;
        rho_2 = opts_my.rho_2;
        rho_3 = opts_my.rho_3;
        rho_4 = opts_my.rho_4;
        rho_5 = opts_my.rho_5;
        rho_6 = opts_my.rho_6;
    end
    
    if k == 35
        opts_my.rho_1 = 1.5* opts_my.rho_1;
        opts_my.rho_2 = 1.5* opts_my.rho_2;
        opts_my.rho_3 = 1.5* opts_my.rho_3;
        opts_my.rho_4 = 1.5* opts_my.rho_4;
        opts_my.rho_5 = 1.5* opts_my.rho_5;
        opts_my.rho_6 = 1.5* opts_my.rho_6;
        rho_1 = opts_my.rho_1;
        rho_2 = opts_my.rho_2;
        rho_3 = opts_my.rho_3;
        rho_4 = opts_my.rho_4;
        rho_5 = opts_my.rho_5;
        rho_6 = opts_my.rho_6;
    end
    
    if k >40
        opts_my.rho_1 = 1.2* opts_my.rho_1;
        opts_my.rho_2 = 1.2* opts_my.rho_2;
        opts_my.rho_3 = 1.2* opts_my.rho_3;
        opts_my.rho_4 = 1.2* opts_my.rho_4;
        opts_my.rho_5 = 1.2* opts_my.rho_5;
        opts_my.rho_6 = 1.2* opts_my.rho_6;
        rho_1 = opts_my.rho_1;
        rho_2 = opts_my.rho_2;
        rho_3 = opts_my.rho_3;
        rho_4 = opts_my.rho_4;
        rho_5 = opts_my.rho_5;
        rho_6 = opts_my.rho_6;
    end

    beta=beta*1.2;
    %% update Rank  
%     for i=1:4
    for i=1:3
        resold{i}=resrank{i};
        MM{i}=reshape(X{i+2}*Y{i+2},Nway_VDT); 
        MMi = MM{i};
        MMi=R0;
        resrank{i}=norm(R0(:)-MMi(:));
        ifrank{i} = abs(1-resrank{i}/resold{i});
%         nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2),size(X{7},2),size(X{8},2)];
        nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2)];
        if ifrank{i}<0.01 && nowrank(i)<max_rank(i)
            [X{i+2},Y{i+2}]=rank_inc_adaptive(X{i+2},Y{i+2},rank_inc);
        end
    end

end

end



%% (Xi, Yi)的初始化函数
function [X0,Y0] = initialMatrix(N,Nway,ranktube)
X0 = cell(1,N-1);Y0 = cell(1,N-1);
dimL = zeros(1,N-1);
dimR = zeros(1,N-1);
IL = 1;
    for k = 1:N-1
        dimL(k) = IL*Nway(k);
        dimR(k) = prod(Nway)/dimL(k);
        %
        X0{k} = randn(dimL(k),ranktube(k));
        Y0{k} = randn(ranktube(k),dimR(k));
        %uniform distribution on the unit sphere
        X0{k} = bsxfun(@rdivide,X0{k},sqrt(sum(X0{k}.^2,1)));
        Y0{k} = bsxfun(@rdivide,Y0{k},sqrt(sum(Y0{k}.^2,2)));
        %
        IL = dimL(k);
    end
end