



function [denoising_image] = Reinex_GLON_Eimg_solve(input, Patch_size)


format compact;
% addpath(fullfile('utilities'));

useGPU      = 1; % CPU or GPU. For single-threaded (ST) CPU computation, use "matlab -singleCompThread" to start matlab.
pauseTime   = 0;
% Patch_size = 300;

load('C:\ICME_20231130\EGSR_20240408\utilize_ywp\CBDNet-master\models\CBDNet_JPEG.mat');

net = dagnn.DagNN.loadobj(net) ;
net.removeLayer('objective1') ;
net.removeLayer('objective2') ;
net.removeLayer('objective_TV') ;
denoiseOutput = net.getVarIndex('prediction') ;
net.vars(net.getVarIndex('prediction')).precious = 1 ;
net.mode = 'test';

if useGPU
   net.move('gpu');
end       




     [w,h,~]=size(input);
     denoising_image = zeros(size(input),'single');
     
    w_num = ceil(w / Patch_size);
    h_num = ceil(h / Patch_size);
    for w_index = 1: w_num
        for h_index = 1: h_num
            start_x = 1 + (w_index - 1)*Patch_size;
            end_x = w_index * Patch_size;
            if end_x > w
                end_x = w;
            end
            start_y = 1 + (h_index - 1)*Patch_size;
            end_y = h_index * Patch_size;
            if end_y > h
                end_y = h;
            end
            image_patch = input(start_x:end_x,start_y:end_y,:);
            [wp,hp,~] = size(image_patch);
            if mod(wp,4) ~= 0
                image_patch = cat(1,image_patch, image_patch([wp:-1:(wp-(4-mod(wp,4))+1)],:,:)) ;
            end
            if mod(hp,4)~=0
                image_patch = cat(2,image_patch, image_patch(:,[hp:-1:(hp-(4-mod(hp,4))+1)],:)) ;
            end
            image_patch = single(image_patch);
            %tic;
            if useGPU
                image_patch = gpuArray(image_patch);
            end
    
            %% set noise level map
            net.eval({'input',image_patch}) ;
    
            output = gather(squeeze(gather(net.vars(denoiseOutput).value)));
            if mod(wp,4) ~= 0
                output = output(1:wp,:,:) ;
            end
            if mod(hp,4)~=0
                output = output(:,1:hp,:) ;
            end
    
            if useGPU
                output = gather(output);
            end
            denoising_image(start_x:end_x,start_y:end_y,:) = output;
        end
    end

   
end









