function [opts_metric] = metric_function_ywp(opts_metric, ith_Img_num, im_num,out_rec, Input_img_RGB, Outputdir,dataset_name,method_name,case_name,gamma_test)
Rec_Img_255 = out_rec;
LL_Img_255 = Input_img_RGB;

addpath(genpath('000.Index_calcu_FTNN_VIF_no_warning'));
addpath(genpath('C:\Program Files\MATLAB\R2022b\toolbox\matlabPyrTools-master\MEX'))
% Img_type ='.png';  % png ,bmp

rec_img_dir = [cd, '\', Outputdir, num2str(gamma_test)];

%% NIQE
% % % % % % load ('modelparameters_NIQE.mat','mu_prisparam','cov_prisparam');
% % % % % % blocksizerow    = 96;
% % % % % % blocksizecol    = 96;
% % % % % % blockrowoverlap = 0;
% % % % % % blockcoloverlap = 0;
% % % % % % NIQE_S = computequality_NIQE(Rec_Img_255,blocksizerow,blocksizecol,blockrowoverlap,blockcoloverlap,mu_prisparam,cov_prisparam);
% % % % % % clear mu_prisparam cov_prisparam
% % % % % % opts_metric.NIQE_arry(1,ith_Img_num) = NIQE_S;
opts_metric.NIQE_arry(1,ith_Img_num) = 0;

%% ILNIQE
% % % % % templateModel = load('templatemodel_ILNIQE.mat');
% % % % % templateModel = templateModel.templateModel;
% % % % % mu_prisparam = templateModel{1};
% % % % % cov_prisparam = templateModel{2};
% % % % % meanOfSampleData = templateModel{3};
% % % % % principleVectors = templateModel{4};
% % % % % ILNIQE_S = computequality(Rec_Img_255,mu_prisparam,cov_prisparam,principleVectors,meanOfSampleData);   % 越小越好
% % % % % clear mu_prisparam cov_prisparam
% % % % % opts_metric.ILNIQE_arry(1,ith_Img_num) = ILNIQE_S;
opts_metric.ILNIQE_arry(1,ith_Img_num) = 0;


%% NIQE_MATLAB
% NIQE_MATLAB_index = niqe(Rec_Img_255);
% NIQE_MATLAB_index = 0;
load ('ywp_NIQE_model_SID_424_Flickr2K_HR2650.mat','ywp_niqe_model_SID_424_Flickr2K_HR2650');
NIQE_MATLAB_index = niqe(Rec_Img_255,ywp_niqe_model_SID_424_Flickr2K_HR2650)
opts_metric.NIQE_MATLAB_arry(1,ith_Img_num) = NIQE_MATLAB_index;

%% BTMQI 
%     btmqi_index = BTMQI(Rec_Img_255);
btmqi_index = 0;
opts_metric.BTMQI_S_arry(1,ith_Img_num) = btmqi_index;
clear model
   
    %% LOE
    LOE_index  = 0;    % uint8 255 
% LOE_index  = LOE(LL_Img_255,Rec_Img_255);    % uint8 255 
opts_metric.LOE_S_arry(1,ith_Img_num) = LOE_index;

%% BRISQUE
    BRISQUE_index = 0;
% BRISQUE_index = brisquescore(Rec_Img_255);
opts_metric.BRISQUE_S_arry(1,ith_Img_num) = BRISQUE_index;
    
%% CEIQ
CEIQ_index  = 0;   % 已验证
opts_metric.CEIQ_B_arry(1,ith_Img_num) = CEIQ_index;

       
%% NIQMC
NIQMC_index = 0;
% NIQMC_index = NIQMC(Rec_Img_255);
opts_metric.NIQMC_B_arry(1,ith_Img_num) = NIQMC_index;
    
%% VIF
VIF_index  = VIF(LL_Img_255,Rec_Img_255);    %  MEX WARNING
opts_metric.VIF_B_arry(1,ith_Img_num) = VIF_index;

%% ARISMC
ARISMC_index_1 = 0;
opts_metric.ARISMC_1_B_arry(1,ith_Img_num) = ARISMC_index_1;
ARISMC_index_2 = 0;
opts_metric.ARISMC_2_B_arry(1,ith_Img_num) = ARISMC_index_2;

%% DIIVINE
DIIVINE_index = 0;  %  MEX WARNING
opts_metric.DIIVINE_B_arry(1,ith_Img_num) = DIIVINE_index;

mean_niqe = mean(opts_metric.NIQE_arry(1,1:ith_Img_num),2);
mean_ilniqe = mean(opts_metric.ILNIQE_arry(1,1:ith_Img_num),2);
mean_niqe_MATLAB = mean(opts_metric.NIQE_MATLAB_arry(1,1:ith_Img_num),2);
mean_BTMQI = mean(opts_metric.BTMQI_S_arry(1,1:ith_Img_num),2);
mean_LOE = mean(opts_metric.LOE_S_arry(1,1:ith_Img_num),2);
mean_BRISQUE = mean(opts_metric.BRISQUE_S_arry(1,1:ith_Img_num),2);
mean_CEIQ = mean(opts_metric.CEIQ_B_arry(1,1:ith_Img_num),2);
mean_NIQMC = mean(opts_metric.NIQMC_B_arry(1,1:ith_Img_num),2);
mean_VIF = mean(opts_metric.VIF_B_arry(1,1:ith_Img_num),2);
mean_ARISMC = mean(opts_metric.ARISMC_2_B_arry(1,1:ith_Img_num),2);
mean_DIIVINE = mean(opts_metric.DIIVINE_B_arry(1,1:ith_Img_num),2);

ZONG_mean_result = [mean_niqe; mean_ilniqe; mean_niqe_MATLAB; mean_BTMQI; mean_LOE; mean_BRISQUE; mean_CEIQ;...
        mean_NIQMC; mean_VIF; mean_ARISMC; mean_DIIVINE]'
% fprintf('截止到第%d张图像，平均指标为：%')


if ith_Img_num == im_num
    Average_results = ["NIQE_S" mean_niqe; "ILNIQE_S" mean_ilniqe; "NIQE_MATLAB" mean_niqe_MATLAB; "BTMQI_S" mean_BTMQI;...
                        "LOE_S" mean_LOE; "BRISQUE_S" mean_BRISQUE; "CEIQ_B" mean_CEIQ;...
                      "NIQMC_B" mean_NIQMC; "VIF_B"  mean_VIF; "ARISMC_B" mean_ARISMC; "DIIVINE_B" mean_DIIVINE];
    All_img_Average_result_name = strcat(rec_img_dir,'\','Average_zong_index_',method_name,dataset_name,case_name,'.xlsx');
    xlswrite(All_img_Average_result_name,Average_results);
%     writematrix(Average_results, All_img_Average_result_name);

    zong_index = zeros(im_num,11);

    zong_index(:,1) = opts_metric.NIQE_arry';
    zong_index(:,2) = opts_metric.ILNIQE_arry';
    zong_index(:,3) = opts_metric.NIQE_MATLAB_arry';
    zong_index(:,4) = opts_metric.BTMQI_S_arry';
    zong_index(:,5) = opts_metric.LOE_S_arry';
    zong_index(:,6) = opts_metric.BRISQUE_S_arry';
    zong_index(:,7) = opts_metric.CEIQ_B_arry';
    zong_index(:,8) = opts_metric.NIQMC_B_arry';
    zong_index(:,9) = opts_metric.VIF_B_arry';
    zong_index(:,10) = opts_metric.ARISMC_2_B_arry';
    zong_index(:,11) = opts_metric.DIIVINE_B_arry';
    zong_index_name = strcat(rec_img_dir,'\','zong_index_',method_name,dataset_name,case_name,'.xlsx');
    xlswrite(zong_index_name,zong_index)
%     writematrix(zong_index, zong_index_name)
end






end