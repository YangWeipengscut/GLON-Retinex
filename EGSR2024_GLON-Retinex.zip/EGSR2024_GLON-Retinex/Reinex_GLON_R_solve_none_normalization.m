function [R_RGB,relerr] = Reinex_GLON_R_solve_none_normalization(R0_VDT, X,Y,P,P1,nway_dila,Nway_VDT,N,opts_my,opt_factor,factor_nway)

       % [R_RGB,relerr] = Reinex_GLON_R_solve(R0_VDT, X,Y,P_RGB,P1_RGB,nway_dila,Nway_VDT,N,opts_my,opt_factor,factor_nway); 
%% 参数初始化
global sigmas
alpha = opts_my.alpha;
theta = opts_my.theta;
sigma_1 = opts_my.sigma_1;
rho_2 = opts_my.rho_2;
beta = opts_my.beta;
beta_1 = opts_my.beta_1;
lambda_2 = opts_my.lambda_2;
tol = opts_my.tol;

%% 反射分量的初始化和VDT相关操作
% R_VDT = R0_VDT;  % VDT后的高阶张量
R_RGB  =  vdt2image_ywp(R0_VDT, factor_nway, nway_dila, opt_factor);
[H,W,c] = size(R_RGB);

%% GPU相关设置
% FFDnet parameter
useGPU      = 1;
    
% FFDnet parameter
if c == 3
    load(fullfile('FFDNet_Clip_color.mat'));
else
    load(fullfile('FFDNet_Clip_gray.mat'));
end
    
net = vl_simplenn_tidy(net);
if useGPU
    net = vl_simplenn_move(net, 'gpu') ;
end

%% 辅助变量（Eimg）和乘子数(J)初始化
Eimg = R_RGB;
J = zeros(size(Eimg));

inner_maxit = 10;
for r = 1:inner_maxit
%     fprintf('内部循环的次数: r =  %d/%d) \n', r, inner_maxit);
    R_last = R_RGB;
    
    
    %% 1) Update epsilon
    input0 = R_RGB - J/theta;
    input = input0;
    fprintf('input的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(input(:)), min(input(:)),class(input));

%     input = single(input); %
    if c==3
        if mod(H,2)==1
            input = cat(1,input, input(end,:,:)) ;
        end
        if mod(W,2)==1
            input = cat(2,input, input(:,end,:)) ;
        end
    else
        if mod(H,2)==1
            input = cat(1,input, input(end,:)) ;
        end
        if mod(W,2)==1
            input = cat(2,input, input(:,end)) ;
        end
    end

    if useGPU
        input = gpuArray(input);
    end
    
    % 全局变量
%     sigmas = sigma_1/(max_in-min_in);
    sigmas = sigma_1;

    res    = vl_simplenn(net,input,[],[],'conserveMemory',true,'mode','test');
    output = res(end).x;
        
%     output(output<0)=0;
    output(output<0)=0;
%     output(output>1)=1;

    

    if c==3
        if mod(H,2)==1
            output = output(1:end-1,:,:);
        end
        if mod(W,2)==1
            output = output(:,1:end-1,:);
        end
    else
        if mod(H,2)==1
            output = output(1:end-1,:);
        end
        if mod(W,2)==1
            output = output(:,1:end-1);
        end
    end

    

    if useGPU
        output = gather(output);
    end
    
    if c==3
        Eimg = double(output);   
    else
        Eimg = origami(double(output),[H W c]);
    end

    fprintf('Eimg的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(Eimg(:)), min(Eimg(:)),class(Eimg));


    %% Update R_RGB
    % 右边的矩阵
    temp1_VDT = image2vdt256_ywp(theta*Eimg+J, opt_factor);  % 第2、3项
    P1_VDT= beta_1*image2vdt256_ywp(P1, opt_factor); % 第4项
    P_VDT= beta*image2vdt256_ywp(P, opt_factor);    % 第5项
    temp_R_VDT = rho_2*R0_VDT; % 第6项
    
    temp = temp1_VDT + P1_VDT + P_VDT + temp_R_VDT;
    % temp累加第1项得到右边的全部
    for n = 1:N-1
        temp = temp + lambda_2*alpha(n)*reshape(X{n}*Y{n},Nway_VDT);
    end
    % 左边个参数之和的常量； (lambda_2 + theta + beta_1 + beta + rho_2)
    %% 求解R的VDT形式
    figure('Name','Eimg'),imshow(Eimg)
    R_VDT = temp/(lambda_2 + theta + beta_1 + beta + rho_2+1);
%     R_VDT(R_VDT<0)=0;

    %% 和GLON的代码不同，该子函数返回RGB形式的反射分量。
    R_RGB  =  vdt2image_ywp(R_VDT, factor_nway, nway_dila, opt_factor);
  
    %% Update 乘子数 和 正则化参数
    J = J + theta * (Eimg - R_RGB);
    theta = theta * 1.2;
        
    %% 迭代停止准则
    relerr(r) = abs(norm(R_RGB(:)-R_last(:)) / norm(R_last(:)));
    fprintf('********************************************外循环第%d次迭代的误差为:%f \n', r, relerr(r));
    if relerr(r) < tol
        break
    end

end

end