
function [out_rec] = L_gamma_255_ywp_max(R_RGB,L,files, Outputdir,methodname,dataset_name,case_name,gamma_end,opts_my)

%% 该函数实现相同的照度和反射分量下，保存不同的gamma值的增强结果

L_hsv = rgb2hsv(L);
L_hsv_v = L_hsv(:,:,3);

temp_max_L = max(L_hsv_v(:))
% opts_my.val_L1  = 150;
% opts_my.val_L2  = 120;
val_L1 = opts_my.val_L1;   % 150
val_L2 = opts_my.val_L2;   % 120

%% 1
% max_L = max(temp_max_L,75)

%% 2
% mean_L = mean(L_hsv_v(:))
% if (temp_max_L-mean_L)>=150
%     fprintf('mean_L + 50 \n ')
%     max_L = mean_L + 90;    % test01: 90; test02:80
% else
%     max_L = max(temp_max_L,85);
%     fprintf('temp_max_L,85 \n')
% end

% max_L = 255;

% 3
if temp_max_L>=val_L1   % 01: 150
    max_L = min(temp_max_L,255);
else
    max_L = max(temp_max_L,val_L2);    % 22：200  23：180
    % v1,v2: 120
end


name_split = split(files.name, '.');

for gamma = 2.2: 0.1 : gamma_end

    if opts_my.uint8_mode ==1    % 255
        L_hsv_v_gamma = (L_hsv_v/255).^(1/gamma);
        L_hsv_v_gamma_max = (L_hsv_v/max_L).^(1/gamma);
    else
        L_hsv_v_gamma = (L_hsv_v/1).^(1/gamma);
    end

%     L_hsv_v_gamma = (L_hsv_v/255).^(1/gamma);
    L_hsv(:,:,3) = L_hsv_v_gamma;
    L_RGB_gamma = hsv2rgb(L_hsv);
    out_rec = R_RGB.*L_RGB_gamma;

    L_hsv(:,:,3) = L_hsv_v_gamma_max;
    L_RGB_gamma_max = hsv2rgb(L_hsv);
    out_rec_max = R_RGB.*L_RGB_gamma_max;

    if ~exist([Outputdir num2str(gamma) '\'], "dir")
        mkdir([Outputdir num2str(gamma) '\'])
    end

    if ~exist([Outputdir num2str(gamma) '_max' '\'], "dir")
        mkdir([Outputdir num2str(gamma) '_max' '\'])
    end
    imwrite(out_rec, [Outputdir num2str(gamma) '\' name_split{1} '_' case_name '_gamma_' num2str(gamma) '.png']);
    imwrite(out_rec_max, [Outputdir num2str(gamma) '_max' '\' name_split{1} '_' case_name '_gamma_' num2str(gamma) '_max.png']);
    fprintf('最终out_rec的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(out_rec(:)), min(out_rec(:)),class(out_rec));
%     imwrite(out_rec, [Outputdir name_split{1} '_' case_name '_gamma_' num2str(gamma) '.png']);
end
imwrite(uint8(L), [Outputdir 'L_'  name_split{1} '_gamma_' num2str(gamma) ...
        methodname dataset_name case_name '.png']);
imwrite((R_RGB), [Outputdir 'R_'  name_split{1} '_gamma_' num2str(gamma) ...
        methodname dataset_name case_name '.png']);


end



%% gamma校正方式：原始方式
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     %% L的gamma校正和最终结果的计算
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv = rgb2hsv(L);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v = L_hsv(:,:,3);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     max_L_hsv_v = max(L_hsv_v(:))
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     max_L_hsv_v = 1;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     % 1) 亮度均一校正
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_gamma = ( L_hsv_v/255 ).^(1/gamma);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_gamma = 255*L_hsv_v_gamma;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_gamma = max_L_hsv_v*L_hsv_v_gamma;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     temp_L_v = max(max(L_hsv_v));
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_norm = L_hsv_v/temp_L_v;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_gamma = ( L_hsv_v_norm ).^(1/gamma);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     % 2) 亮度分段校正
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     temp_max = max(L_hsv(:))
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     dim_hsv = size(L_hsv);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_gamma = zeros(dim_hsv(1),dim_hsv(2));
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     for i = 1:dim_hsv(1)
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         for j = 1:dim_hsv(2)
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %             if L_hsv(i,j,3) <= 0.8*temp_max
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %                 L_hsv_gamma(i, j) = L_hsv(i,j,3).^(1/3);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %             else
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %                 L_hsv_gamma(i, j) = L_hsv(i,j,3).^(1/2.2);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %             end
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         end
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     end
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv(:,:,3) = L_hsv_v_gamma;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_RGB_gamma = hsv2rgb(L_hsv);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     fprintf('最终L_RGB_gamma的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(L_RGB_gamma(:)), min(L_RGB_gamma(:)),class(L_RGB_gamma));
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     out_rec = R_RGB.*L_RGB_gamma;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     out_rec(out_rec>1) =1 ;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     fprintf('增强结果out_rec的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(out_rec(:)), min(out_rec(:)),class(out_rec));
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     %% 时间记录（Time recording）
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     time_Retinex_GLON(i_th,1) = toc(time_start);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     time_single = time_Retinex_GLON(i_th,1)
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     %% 增强图像以及L和R的保存
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     name_split = split(files(i_th).name, '.');
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite((out_rec), [Outputdir name_split{1} '_' case_name '.png']);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite(uint8(out_rec), [Outputdir name_split{1} '_' case_name '_255.png']);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite(uint8(L), [Outputdir 'L_'  name_split{1} '_gamma_' num2str(gamma) ...
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         methodname dataset_name case_name '.png']);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite((R_RGB), [Outputdir 'R_'  name_split{1} '_gamma_' num2str(gamma) ...
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         methodname dataset_name case_name '.png']);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite(uint8(R_RGB), [Outputdir 'R_'  name_split{1} '_gamma_' num2str(gamma) ...
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         methodname dataset_name case_name '.png']);



