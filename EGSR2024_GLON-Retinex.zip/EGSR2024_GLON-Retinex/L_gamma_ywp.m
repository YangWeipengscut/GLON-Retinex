
function [] = L_gamma_ywp(R_RGB,L,files, Outputdir,methodname,dataset_name,case_name)
% L_gamma_ywp(R_RGB,L,files(i_th), Outputdir,methodname,dataset_name,case_name)


dim = size(L);
A = zeros(1,dim(3));
B = zeros(1,dim(3));
for i = 1:dim(3)
    temp_L = L(:,:,i);
    A(i) = max(temp_L(:));
    L(:,:,i) = L(:,:,i)/A(i);

    temp_R = R_RGB(:,:,i);
    B(i) = max(temp_R(:));
    R_RGB(:,:,i) = R_RGB(:,:,i)/B(i);
end

max_L = max(L(:)); min_L = min(L(:));
L = (L - min_L)/(max_L - min_L);

max_R_RGB = max(R_RGB(:)); min_R_RGB = min(R_RGB(:));
R_RGB = (R_RGB - min_R_RGB)/(max_R_RGB - min_R_RGB);

L_hsv = rgb2hsv(L);
L_hsv_v = L_hsv(:,:,3);

name_split = split(files.name, '.');

for gamma = 2.2: 0.1 : 2.2
    L_hsv_v_gamma = (L_hsv_v).^(1/gamma);
    L_hsv(:,:,3) = L_hsv_v_gamma;
    L_RGB_gamma = hsv2rgb(L_hsv);
    out_rec = R_RGB.*L_RGB_gamma;
    imwrite(out_rec, [Outputdir name_split{1} '_' case_name '_gamma_' num2str(gamma) '.png']);
end
imwrite(L, [Outputdir 'L_'  name_split{1} '_gamma_' num2str(gamma) ...
        methodname dataset_name case_name '.png']);
imwrite((R_RGB), [Outputdir 'R_'  name_split{1} '_gamma_' num2str(gamma) ...
        methodname dataset_name case_name '.png']);


end



%% gamma校正方式：原始方式
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     %% L的gamma校正和最终结果的计算
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv = rgb2hsv(L);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v = L_hsv(:,:,3);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     max_L_hsv_v = max(L_hsv_v(:))
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     max_L_hsv_v = 1;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     % 1) 亮度均一校正
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_gamma = ( L_hsv_v/255 ).^(1/gamma);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_gamma = 255*L_hsv_v_gamma;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_gamma = max_L_hsv_v*L_hsv_v_gamma;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     temp_L_v = max(max(L_hsv_v));
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_norm = L_hsv_v/temp_L_v;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_v_gamma = ( L_hsv_v_norm ).^(1/gamma);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     % 2) 亮度分段校正
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     temp_max = max(L_hsv(:))
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     dim_hsv = size(L_hsv);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv_gamma = zeros(dim_hsv(1),dim_hsv(2));
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     for i = 1:dim_hsv(1)
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         for j = 1:dim_hsv(2)
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %             if L_hsv(i,j,3) <= 0.8*temp_max
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %                 L_hsv_gamma(i, j) = L_hsv(i,j,3).^(1/3);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %             else
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %                 L_hsv_gamma(i, j) = L_hsv(i,j,3).^(1/2.2);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %             end
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         end
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     end
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_hsv(:,:,3) = L_hsv_v_gamma;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     L_RGB_gamma = hsv2rgb(L_hsv);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     fprintf('最终L_RGB_gamma的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(L_RGB_gamma(:)), min(L_RGB_gamma(:)),class(L_RGB_gamma));
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     out_rec = R_RGB.*L_RGB_gamma;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     out_rec(out_rec>1) =1 ;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     fprintf('增强结果out_rec的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(out_rec(:)), min(out_rec(:)),class(out_rec));
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     %% 时间记录（Time recording）
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     time_Retinex_GLON(i_th,1) = toc(time_start);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     time_single = time_Retinex_GLON(i_th,1)
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     %% 增强图像以及L和R的保存
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     name_split = split(files(i_th).name, '.');
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite((out_rec), [Outputdir name_split{1} '_' case_name '.png']);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite(uint8(out_rec), [Outputdir name_split{1} '_' case_name '_255.png']);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite(uint8(L), [Outputdir 'L_'  name_split{1} '_gamma_' num2str(gamma) ...
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         methodname dataset_name case_name '.png']);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite((R_RGB), [Outputdir 'R_'  name_split{1} '_gamma_' num2str(gamma) ...
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         methodname dataset_name case_name '.png']);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %     imwrite(uint8(R_RGB), [Outputdir 'R_'  name_split{1} '_gamma_' num2str(gamma) ...
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % %         methodname dataset_name case_name '.png']);



