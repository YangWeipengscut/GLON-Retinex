clc; clear all; close all;
addpath(genpath(cd));

rand('seed',213412); 
% addpath('D:\Programefiles_ywp\MATLAB2022\matconvnet')
% addpath('D:\Programefiles_ywp\MATLAB2022\toolbox\matconvnet\matlab\')
addpath('D:\Programefiles_ywp\MATLAB2022\toolbox\matconvnet\matlab\mex\')




EN_GLON      = 1; % Ours

methodname  = {'HaLRTC','tSVD','TMac-TT','KBR','TT-TV','GLON'};

% X0   = double(imread('2015_00026.jpg'));
X0   = double(imread('8005.jpg'));

% X0   = double(imread('baboon.bmp'));
% nway = size(X0);
X0   = min( 255, max( X0, 0 ));
name = {'2015_00026.jpg'};

% [X_dila, opt_factor] = image_dilation_ywp(imread('baboon.bmp'));
% [X_dila, opt_factor] = image_dilation_ywp(imread('2015_00026.jpg'));
[X_dila, opt_factor] = image_dilation_ywp(imread('8005.jpg'));
% [X_dila, opt_factor] = image_dilation_ywp(imread('7001.jpg'));
% X0 = double(X_dila);
nway = size(X_dila)

for SR = [0.5]
    %% Generate known data
%     Nway = size( image2vdt256(X0) );
%     image2vdt256_ywp(X_dila)
    [Xtrue,factor_nway, permute_nway] =  image2vdt256_ywp(X_dila, opt_factor);
    Xtrue = double(Xtrue);
    Nway = size( Xtrue);
    P = round(SR*prod(Nway));      % prod���س˻�
    Known = randsample(prod(Nway),P);
    [Known,~] = sort(Known);    % ��������
    
    %% Ket Augmentation
%     Xtrue =  image2vdt256(X0);
%     [Xtrue,factor_nway, permute_nway] =  image2vdt256_ywp(double(X_dila), opt_factor);
    %% Missing data
    Xkn          = Xtrue(Known);   %  Xkn ��
    Xmiss        = zeros(Nway);
    Xmiss(Known) = Xkn;


%     Xmiss        = vdt2image256(Xmiss);
    Xmiss = vdt2image_ywp(Xmiss, factor_nway, nway, opt_factor);
    figure('Name','�������ͼ��'),imshow(uint8(Xmiss))
        
    imname=[num2str(name{1}),'_tensor0','_SR_',num2str(SR),'.mat'];
    save(imname,'X0','Xmiss','Xkn','Known');
    
        
    %% GLON
    j = j+1;
    if EN_GLON 
        %%%%%
        fprintf('\n');
%         disp(['performing ',methodname{j}, ' ... ']);
%         addpath matlab
        opts = [];
        opts.tol    = 2*1e-3;
        opts.maxit  = 3;
        opts.X0     = X0;
        opts.rho    = 5;
        
        for th = [0.01]
            for sigma1 =[0.04]
                for sigma2 =[100]
                    for beta1 = [100]
                        for beta2 =[20]
                            time_GLON_start = tic;
                            opts.th     = th;
                            opts.sigma1  = sigma1;
                            opts.sigma2  = sigma2;
                            opts.beta1   = beta1;
                            opts.beta2   = beta2;      
                            [X, Out_TT_FFDnet] = TT_FFDnet_BM3D( Xkn, Known, Nway, opts, factor_nway, permute_nway, nway,opt_factor);
%                             [X, Out_TT_FFDnet] = TT_FFDnet_BM3D( Xkn, Known, Nway, opts);

                            size_X1  = size(X)

                            X = vdt2image_ywp(X, factor_nway, nway, opt_factor);
                            %% �ü�
                            X = X(1:opt_factor.H_ini,1:opt_factor.W_ini,:);

                            X = min( 255, max( X, 0 ));

                            time_GLON = toc(time_GLON_start)
                            
                            size_X0 = size(X0);
                            size_X  = size(X);

                            figure('Name', '��ԭ���ͼ��Ա�'),
                            subplot(121), imshow(uint8(X0)),title('ԭͼ��'),
                            subplot(122), imshow(uint8(X)),title('��ԭ��ü����ͼ��')
                            
                            for i=1:1:3
                                PSNRvector(i) = psnr3(X0(:,:,i)/255,X(:,:,i)/255);
                            end
                            psnr = mean(PSNRvector);
                                                         
                            for i=1:1:3
                                SSIMvector(i)=ssim3(X0(:,:,i),X(:,:,i));
                            end
                            ssim = mean(SSIMvector);
                                           
                            display(sprintf('psnr=%.2f,ssim=%.4f,th=%.2f,sigma1=%.6f,sigma2=%.6f,beta1=%.8f,beta2=%.8f',psnr, ssim, opts.th, opts.sigma1, opts.sigma2, opts.beta1, opts.beta2))
                            display(sprintf('=================================='))
                                
%                             imname=[num2str(name{1}),'_SR_',num2str(SR),'_result_',num2str(methodname{j}),'_psnr_',num2str(psnr,'%.2f'),'_ssim_',num2str(ssim,'%.4f'),'_th_',num2str(opts.th),'_sigma1_',num2str(opts.sigma1),'_sigma2_',num2str(opts.sigma2),'_beta1_',num2str(opts.beta1),'_beta2_',num2str(opts.beta2),'.mat'];
%                             save(imname,'X','Out_TT_FFDnet','time_GLON');
                        end
                    end
                end
            end
        end
    end    
end