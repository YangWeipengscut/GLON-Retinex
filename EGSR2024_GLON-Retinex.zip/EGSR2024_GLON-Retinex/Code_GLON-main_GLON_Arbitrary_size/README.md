# Code_GLON

@article{Zhao2021TIP,

  title={Tensor Completion via Complementary Global, Local, and Nonlocal Priors},
  
  author={Zhao, X. L. and Yang, J. H. and Ma, T. H.  and Jiang, T.  X. and Ng, M. K.},
  
  journal={IEEE Trans. Image Process.},
  
  volume={31},
  
  pages={984-999},
  
  year={2022},
}

The main function: Demo_LRTC.
The compared methods: HaLRTC, TSVD, KBR, TMac-TT, and TT-TV.
