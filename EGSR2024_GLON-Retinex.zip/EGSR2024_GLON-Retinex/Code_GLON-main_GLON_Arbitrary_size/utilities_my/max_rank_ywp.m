function max_rank = max_rank_ywp(opt_factor)
Len = opt_factor.length_factor_1;  % Len： 高和宽质因数分解的长度
if Len >= 5
    d = Len+1 - 2 -3;% 待更新张量的维度 9-2-3 = 4;原因详见GLON论文中的公式(30)
    % d-2-3，也就是说前2个秩和后2(L-1)个秩不需要更新； L是VDT后高阶张量的维度(包括通道维度)
    % 但如果质因数分解的长度小于等于5呢？秩就不需要更新
    
    switch d
        case 1
            max_rank = [30];   % 质因数分解的长度为5
        case 2
            max_rank = [30 30];   % 质因数分解的长度为6
        case 3
            max_rank = [30 50 30];   % 质因数分解的长度为7
        case 4
            max_rank = [30 50 50 30];   % 质因数分解的长度为8
        case 5
            max_rank = [30 45 50 45 30];   % 质因数分解的长度为9
        case 6
            max_rank = [30 45 50 50 45 30];   % 质因数分解的长度为10
        case 7
            max_rank = [30 40 45 50 45 40 30];   % 质因数分解的长度为11
        case 8
            max_rank = [30 40 45 50 50 45 40 30];   % 质因数分解的长度为12
        case 9
            max_rank = [30 35 40 45 50 45 40 35 30];   % 质因数分解的长度为13
        case 10
            max_rank = [30 35 40 45 50 50 45 40 35 30];   % 质因数分解的长度为14
    end

else
    switch Len
        case 1   % l = 
            max_rank = [30];    % 质因数分解的长度为1
        case 2
            max_rank = [30 30];     % 质因数分解的长度为2
        case 3
            max_rank = [30 50 30];     % 质因数分解的长度为3
        case 4
            max_rank = [30 50 50 30];   % 质因数分解的长度为4
    end

end
