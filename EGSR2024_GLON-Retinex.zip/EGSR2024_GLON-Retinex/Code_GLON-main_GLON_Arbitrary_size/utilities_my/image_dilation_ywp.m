function [X_dila, opt_factor] = image_dilation_ywp(X0)

% X_dila: X0扩充后的图像图像

[H_ini,W_ini,~] = size(X0);

factor_1 = factor(H_ini);
factor_1_ini = factor_1;
length_factor_1 = length(factor_1);
length_factor_1_ini = length_factor_1;

factor_2 = factor(W_ini);
factor_2_ini = factor_2;
length_factor_2 = length(factor_2);
length_factor_2_ini = length_factor_2;


% 最终分解结果的初始化
H_final = H_ini;
W_final = W_ini;

factor_1_final = factor_1;
factor_2_final = factor_2;

while length_factor_1~=length_factor_2
    if length_factor_1 < length_factor_2
        H_final = H_final + 1;
        factor_1_final = factor(H_final);
        length_factor_1 = length(factor_1_final);

    else
        W_final = W_final + 1;
        factor_2_final = factor(W_final);
        length_factor_2 = length(factor_2_final);

    end
end

H_add = H_final-H_ini;
W_add = W_final-W_ini;


% % % % % % % % % % % % % % fprintf('initi H = %d, factor_length = %d ; W = %d, factor_length = %d. \n', ...
% % % % % % % % % % % % % %     H_ini, length_factor_1_ini, W_ini, length_factor_2_ini);
% % % % % % % % % % % % % % 
% % % % % % % % % % % % % % fprintf('final H = %d, factor_length = %d ; W = %d, factor_length = %d .\n', ...
% % % % % % % % % % % % % %     H_final,length_factor_1, W_final,length_factor_2);
% % % % % % % % % % % % % % 
% % % % % % % % % % % % % % fprintf('H 增加了%d, W增加了%d. \n', H_add, W_add)


%% 图像的高度H方向的复制（复制最后一行）
X_dila = X0;
% % % % % % % % % % % % % % fprintf(['扩充前X_dila的维度为: ', num2str(size(X_dila)), '\n' ])


% fprintf(['扩充前X_dila高和宽的质因数分解为:  ', '高：' ,num2str(factor_1_ini), ';', '宽：',num2str(factor_2_ini) , '\n' ])

% for i = 1: H_add
%     X_dila = cat(1,X_dila, X_dila(end,:,:));
% end

X_H_add = repmat(X_dila(end,:,:), H_add, 1,1);
X_dila = cat(1, X_dila, X_H_add);

%% 图像的宽度方向的复制（复制最后一列）

% for i = 1: W_add
%     X_dila = cat(2,X_dila, X_dila(:,end,:)) ;
% end

X_W_add = repmat(X_dila(:,end,:), 1, W_add, 1);
X_dila = cat(2,X_dila,X_W_add);

% % % % % % % fprintf(['扩充后X_dila的维度为: ', num2str(size(X_dila)), '\n' ])
% % % % % % % fprintf(['扩充前X_dila高和宽的质因数分解为:  ', '高：' ,num2str(factor_1_ini), ';', '宽：',num2str(factor_2_ini) , '\n' ])
% % % % % % % fprintf(['扩充前X_dila高和宽的质因数分解为:  ', '高：' ,num2str(factor_1_final), ';', '宽：',num2str(factor_2_final) , '\n' ])


opt_factor.H_ini = H_ini;
opt_factor.W_ini = W_ini;
opt_factor.H_final = H_final;
opt_factor.W_final = W_final;
opt_factor.H_add = H_add;
opt_factor.W_add = W_add;
opt_factor.length_factor_1 = length_factor_1;   % 统一的质因数分解的长度
opt_factor.factor_1_final = factor_1_final;   % 统一长度的质因数分解
opt_factor.factor_2_final = factor_2_final;   % 统一长度的质因数分解

end