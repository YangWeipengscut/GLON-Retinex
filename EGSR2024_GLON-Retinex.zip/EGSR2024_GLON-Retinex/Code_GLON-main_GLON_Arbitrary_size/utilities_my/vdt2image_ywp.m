function [B1] = vdt2image_ywp(X_dila, factor_nway, nway,opt_factor)

% [height,weight,c] = size(X_dila);
B1 = (X_dila);

K1 = opt_factor.factor_1_final;
K2 = opt_factor.factor_2_final;

reshape_inv_nway = [];
Len = opt_factor.length_factor_1;
for i = 1:Len
    reshape_inv_nway = cat(2, reshape_inv_nway, [K1(i) K2(i)]);
end

reshape_inv_nway = cat(2, reshape_inv_nway, 3);

B1 = reshape(B1, reshape_inv_nway);


% permute_nway = [1 3 5 7 9 11 13 15 17 2 4 6 8 10 12 14 16 18 19]

seq_1 = 1:2:(2*Len-1);
seq_2 = 2:2:(2*Len);
% fprintf('vdt2image_ywp:')

permute_nway = cat(2, seq_1, seq_2, 2*Len+1);
B1 = permute(B1, permute_nway);

B1 = reshape(B1,nway);

end

