function [B1] = vdt2image_ywp(X_dila, factor_nway, nway,opt_factor)

% [height,weight,c] = size(X_dila);
B1 = double(X_dila);
B1 = reshape(B1, factor_nway);

% Len = opt_factor.length_factor_1;
d = opt_factor.length_factor_1;


% permute_nway = [1 3 5 7 9 11 13 15 17 2 4 6 8 10 12 14 16 18 19]

% seq_1 = 1:2:(2*d-1);
% seq_2 = 2:2:(2*d);

seq_1 = 1:2:(2*d-1);
seq_2 = 2:2:(2*d);
fprintf('vdt2image_ywp:')

permute_nway = cat(2, seq_1, seq_2, 2*d+1)
B1 = permute(B1, permute_nway);

B1 = reshape(B1,nway);

end

