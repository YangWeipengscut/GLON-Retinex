function [X_dila, opt_factor] = image_dilation_ywp(X0)

% [H_fin,W_fin,~] = size(X);

X = X(1:opt_factor.H_ini,:,:);
X = X(:,1:opt_factor.W_ini,:);


end