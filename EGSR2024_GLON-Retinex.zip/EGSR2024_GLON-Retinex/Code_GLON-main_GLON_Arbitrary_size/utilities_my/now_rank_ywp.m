function nowrank = now_rank_ywp(X, opt_factor)
Len = opt_factor.length_factor_1 ;  % Len： 高和宽质因数分解的长度

    switch Len
        case 1
            nowrank=[size(X{1},1)];   % 质因数分解的长度为1
        case 2
            nowrank=[size(X{1},1),size(X{2},1)];   % 质因数分解的长度为2
        case 3
           nowrank=[size(X{1},1),size(X{2},1),size(X{3},1)];   % 质因数分解的长度为8
        case 4
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2)];   % 质因数分解的长度为9
        case 5
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2)];   % 质因数分解的长度为10
        case 6
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2)];   % 质因数分解的长度为11
        case 7
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2),size(X{7},2)];   % 质因数分解的长度为12
        case 8
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2),size(X{7},2),size(X{8},2)];   % 质因数分解的长度为13
        case 9
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2),size(X{7},2),size(X{8},2),size(X{9},2)];   % 质因数分解的长度为14
        case 10
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2),size(X{7},2),size(X{8},2),size(X{9},2),size(X{10},2)];   % 质因数分解的长度为14
        case 11
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2),size(X{7},2),size(X{8},2),size(X{9},2),size(X{10},2),size(X{11},2)];   % 质因数分解的长度为14
        case 12
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2),size(X{7},2),size(X{8},2),size(X{9},2),size(X{10},2),size(X{11},2),size(X{12},2)];   % 质因数分解的长度为14
        case 13
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2),size(X{7},2),size(X{8},2),size(X{9},2),size(X{10},2),size(X{11},2),size(X{12},2),size(X{13},2)];   % 质因数分解的长度为14
        case 14
            nowrank=[size(X{1},1),size(X{2},1),size(X{3},1),size(X{4},2),size(X{5},2),size(X{6},2),size(X{7},2),size(X{8},2),size(X{9},2),size(X{10},2),size(X{11},2),size(X{12},2),size(X{13},2),size(X{14},2)];   % 质因数分解的长度为14
    end




end
