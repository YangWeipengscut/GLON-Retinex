function ranktube = ranktube_ywp(seq_len)

switch seq_len
    case 1
        ranktube = [3];
    case 2
        ranktube = [4, 3];
    case 3
        ranktube = [4, 16, 3];
    case 4
        ranktube = [4, 16, 5, 3];
    case 5
        ranktube = [4, 16, 5, 5, 3];
    case 6
        ranktube = [4, 16, 5, 5, 5, 3];
    case 7
        ranktube = [4, 16, 5, 5, 5, 5, 3];
    case 8
        ranktube = [4, 16, 5, 5, 5, 5, 12, 3];
    case 9
        ranktube = [4, 16, 5, 5, 5, 5, 12, 10, 3];
    case 10
        ranktube = [4, 16, 5, 5, 5, 5, 12, 10, 6, 3];
    case 11
        ranktube = [4, 16, 5, 5, 5, 5, 12, 10, 6, 8, 3];
    case 12
        ranktube = [4, 16, 5, 5, 5, 5, 12, 10, 6, 8, 6, 3];
    case 13
        ranktube = [4, 16, 5, 5, 5, 5, 12, 10, 6, 8, 6, 6, 3];
    case 14
        ranktube = [4, 16, 5, 5, 5, 5, 12, 10, 6, 8, 6, 6, 8, 3];
end

 