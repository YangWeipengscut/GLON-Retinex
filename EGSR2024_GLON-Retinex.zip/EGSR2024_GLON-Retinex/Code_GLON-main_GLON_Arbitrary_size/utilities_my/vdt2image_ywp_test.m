
[height,weight,c] = size(X_dila);
B1 = double(X_dila);



B1 = reshape(B1, factor_nway);

B1 = permute(B1, permute_nway);

B1 = reshape(B1,[height,weight,c]);
