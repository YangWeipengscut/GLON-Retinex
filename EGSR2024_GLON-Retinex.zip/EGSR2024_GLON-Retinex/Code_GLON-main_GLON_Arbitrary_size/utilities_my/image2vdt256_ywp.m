function [B_VDT,factor_H_W_C, permute_nway] =  image2vdt256_ywp( B, opt_factor)

[~,~,c] = size(B);
factor_H_W_C = cat(2,opt_factor.factor_1_final,opt_factor.factor_2_final,3);
B =  reshape(B, factor_H_W_C);

%% 
Len = opt_factor.length_factor_1;  
% Len = 9时，permute_nway 应为 [1 10 2 11 3 12 4 13 5 14 6 15 7 16 8 17 9 18 19]。
permute_nway = [];
for i = 1:Len
    seq = [i, i+Len];
    permute_nway = cat(2, permute_nway, seq);
end
permute_nway = cat(2, permute_nway, 2*Len+1);
B =  permute(B, permute_nway);

%%
K1 = opt_factor.factor_1_final;
K2 = opt_factor.factor_2_final;
reshape_nway = [];
for i = 1:Len
    reshape_nway = cat(2, reshape_nway, K1(i)*K2(i));
end
reshape_nway = cat(2, reshape_nway, c);
B_VDT = reshape(B, reshape_nway);

end