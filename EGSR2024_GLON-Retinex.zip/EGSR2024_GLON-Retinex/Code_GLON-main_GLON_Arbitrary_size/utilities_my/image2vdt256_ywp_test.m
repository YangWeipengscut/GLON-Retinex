
[~,~,c] = size(X_dila);
B = double(X_dila);

nway = cat(2,opt_factor.factor_1_final,opt_factor.factor_2_final,3);

B =  reshape(B, nway);

%% 
Len = opt_factor.length_factor_1;  % 9
% [1 10 2 11 3 12 4 13 5 14 6 15 7 16 8 17 9 18 19]
permute_nway = [];
for i = 1:Len
    seq = [i, i+Len];
    permute_nway = cat(2, permute_nway, seq);
end

permute_nway = cat(2, permute_nway, 2*Len+1)
    
B =  permute(B, permute_nway);

K1 = opt_factor.factor_1_final;
K2 = opt_factor.factor_2_final;

reshape_nway = [];
for i = 1:Len
    reshape_nway = cat(2, reshape_nway, K1(i)*K2(i));
end
reshape_nway = cat(2, reshape_nway, c);

B = reshape(B, reshape_nway);



