function [R_destripe] = destripe_CBDNet_ywp(R1,patch_size_1,R2,patch_size_2)
% patch_size_2 > patch_size_1

r = 20;

[h,w,c] = size(R2);  % 高 * 宽 *channel
h_floor = floor(h/patch_size_2);
w_floor = floor(w/patch_size_2);

for k_h = 1:h_floor
    R2(max(0,k_h*patch_size_2-r):min(h,k_h*patch_size_2+r),:,:) = R1(max(0,k_h*patch_size_2-r):min(h,k_h*patch_size_2+r),:,:);
end

for k_w = 1:w_floor

    R2(:,max(0,k_w*patch_size_2-r):min(w,k_w*patch_size_2+r),:) = R1(:,max(0,k_w*patch_size_2-r):min(w,k_w*patch_size_2+r),:);
end

R_destripe = R2;





end