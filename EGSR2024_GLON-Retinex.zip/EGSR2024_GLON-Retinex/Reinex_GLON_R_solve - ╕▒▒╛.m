function [R_RGB,relerr] = Reinex_GLON_R_solve(R0, X,Y,P,P1,nway_dila,Nway_VDT,N,opts_my,opt_factor,factor_nway)

%% 参数初始化
global sigmas
alpha = opts_my.alpha;

theta = opts_my.theta;
sigma_1 = opts_my.sigma_1;

rho_2 = opts_my.rho_2;
beta = opts_my.beta;
beta_1 = opts_my.beta_1;
lambda_2 = opts_my.lambda_2;
tol = opts_my.tol;




%% 反射分量的初始化和VDT相关操作
R = R0;  % VDT后的高阶张量
R_RGB  =  vdt2image_ywp(R0, factor_nway, nway_dila, opt_factor);
[w,h,c] = size(R_RGB);

%% GPU相关设置
% FFDnet parameter
useGPU      = 1;
    
% FFDnet parameter
if c == 3
    load(fullfile('FFDNet_Clip_color.mat'));
else
    load(fullfile('FFDNet_Clip_gray.mat'));
end
    
net = vl_simplenn_tidy(net);
if useGPU
    net = vl_simplenn_move(net, 'gpu') ;
end


%% 辅助变量（Eimg）和乘子数(J)初始化
Eimg = R_RGB;
J = zeros(size(Eimg));

inner_maxit = 20;
for r = 1:inner_maxit
    fprintf('内部循环的次数: r =  %d (%d)', r, inner_maxit);
    R_last = R_RGB;
    
    
    %% Update epsilon
    R_RGB  =  vdt2image_ywp(R, factor_nway, nway_dila, opt_factor);
    input0 = R_RGB - J/theta;

    %% 分通道除以最大值
    A = zeros(1,c);
    for i= 1:c
        Temp = input0 (:,:,i);
        A(i) = max(Temp(:));
        input0(:,:,i) =  Temp /A(i);
    end
            
    if c==3
        input = input0;
    else
        input = unorigami(input0,[w h c]);
    end


    input = single(input); %
    if c==3
        if mod(w,2)==1
            input = cat(1,input, input(end,:,:)) ;
        end
        if mod(h,2)==1
            input = cat(2,input, input(:,end,:)) ;
        end
    else
        if mod(w,2)==1
            input = cat(1,input, input(end,:)) ;
        end
        if mod(h,2)==1
            input = cat(2,input, input(:,end)) ;
        end
    end

    if useGPU
        input = gpuArray(input);
    end
    max_in = max(input(:));min_in = min(input(:));
    input = (input-min_in)/(max_in-min_in);

    % 全局变量
    sigmas = sigma_1/(max_in-min_in);

    res    = vl_simplenn(net,input,[],[],'conserveMemory',true,'mode','test');
    output = res(end).x;
        
    output(output<0)=0;output(output>1)=1;
    output = output*(max_in-min_in)+min_in;

    if c==3
        if mod(w,2)==1
            output = output(1:end-1,:,:);
        end
        if mod(h,2)==1
            output = output(:,1:end-1,:);
        end
    else
        if mod(w,2)==1
            output = output(1:end-1,:);
        end
        if mod(h,2)==1
            output = output(:,1:end-1);
        end
    end

    

    if useGPU
        output = gather(output);
    end
    
    if c==3
        Eimg = double(output);   
    else
        Eimg = origami(double(output),[w h c]);
    end
    
    for i= 1:c
        Eimg(:,:,i) =   A(i)*Eimg(:,:,i);
    end

    %% Update R_RGB
    % 右边的矩阵
    temp1_VDT = image2vdt256_ywp(theta*Eimg+J, opt_factor);  % 第2、3项
    P_1_VDT= beta_1*image2vdt256_ywp(P1, opt_factor); % 第4项
    P_VDT= beta*image2vdt256_ywp(P, opt_factor);    % 第5项
    temp_R_VDT = rho_2*R0; % 第6项
    
    temp = temp1_VDT + P_1_VDT + P_VDT + temp_R_VDT;
    % temp累加第1项得到右边的全部
    for n = 1:N-1
        temp = temp + lambda_2*alpha(n)*reshape(X{n}*Y{n},Nway_VDT);
    end
    % 左边个参数之和的常量； (lambda_2 + theta + beta_1 + beta + rho_2)
    R_RGB = temp/(lambda_2 + theta + beta_1 + beta + rho_2);
    R_RGB = max(0,min(R_RGB,255));

    %% 和GLON的代码不同，该子函数返回RGB形式的反射分量。
    R_RGB  =  vdt2image_ywp(R_RGB, factor_nway, nway_dila, opt_factor);


    
    %% Update 乘子数 和 正则化参数
%     size_1 = size(J);  % 400 * 600 *3
%     size_2 = size(Eimg);  % 400 * 600 *3
%     size_3 = size(R_RGB);  % 400 * 600 *3
%     size_1 = size(J)
    J = J + theta * (Eimg - R_RGB);
    theta = theta * 1.2;
        
    %% 迭代停止准则
    relerr(r) = abs(norm(R_RGB(:)-R_last(:)) / norm(R_last(:)));
    if relerr(r) < tol
        break
    end

end

end