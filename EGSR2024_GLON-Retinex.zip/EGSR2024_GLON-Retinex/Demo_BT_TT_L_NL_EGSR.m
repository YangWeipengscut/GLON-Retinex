
%% Models based on mBTV, tensor train rank, Local Prior (FFDnet) and non-local prior (CBM3D)
% Method name: Retinex_GLON

clear;close all;clc;
%% 添加路径（Add path）
% parpool(12)
parpool('Processes',12)
% parpool(12);

addpath(genpath(cd));
% addpath(genpath("D:\Programefiles_ywp\MATLAB2022\toolbox\matconvnet\matlab\mex\"))
addpath(genpath("C:\Program Files\MATLAB\R2022b\toolbox\matconvnet\matlab\mex\"))


%% 原始RGB图像的路径的加载（Load the path of the original RGB image）
% 基础和消融实验 (The name of the base and ablation experiment)
methodname = '_GLON';
% lambda
opts_my = [];

% case_name = 'Case8_test20_红点_test2';
% case_name = 'Case_02_test_13';
% case_name = 'Case_937_050_CBDNet_test20240204';
% case_name = 'Case_03_max_CPU_test';
case_name = 'Case_04_max';
%% 参数设置（Parameter setting）
% opts_my = [];
opts_my.tol = 2*1e-6;   % 参考GLON的参数设置(Refer to GLON parameter Settings)
opts_my.maxit = 5;   % 5
opts_my.im_show = 0;
opts_my.text_show = 0;
opts_my.psnr_ssiim_dis = 0;
opts_my.debug = 0;
test_th = 527;

% opts_my.val_L1  = 150;   % 'Case_02_max';
% opts_my.val_L2  = 120;

opts_my.val_L1  = 140;    % 'Case_03_max';
opts_my.val_L2  = 100;

opts_my.uint8_mode =1;

% rho
opts_my.rho_GLON = 0.07;    % 0.05; 参考GLON的rho = 5参数设置(Refer to GLON parameter Settings)
% rho_GLON越小，增强的结果越亮，都不用增加gamma到2.6。
% rho_GLON太大，低秩先验无效
% Case8_test8 ：

% % % % lambda
opts_my.lambda_1 = 0.05;    % L的mBTV  0.01  

opts_my.lambda_2 = 0.01;     % 0.01 Global prior: TT rank. 参考GLON的参数设置(Refer to GLON parameter Settings)
opts_my.lambda_3 = 0.015;    % 0.0008，平滑效果就很好了; Local prior, 使用CBDNet时此参数不起作用;
opts_my.lambda_4 = 0.0015;          % 0.0015;  None_local prior: CBM3D 参考GLON的参数设置(Refer to GLON parameter Settings)
% lambda_4对应论文中的lambda_3

gamma_end = 3.2;

% Plug-and-play (FFDnet和CBM3D)中的参数
% 辅助变量P、P1相关的正则化参数
opts_my.beta = 0.5; % 5; P问题中; CBM3D; 参考GLON的beta2=20参数设置(Refer to GLON parameter Settings)
% 增大beta会使得增强结果更亮，甚至过饱增强，P的误差曲线下降的也慢。
%% 由模型可得，增大beta，有助于使得P的分布更靠近R，远离输入图像的分布。
%% 但是目前，经过CBM3D平滑后的P还无法传递到R
opts_my.beta_1 = 6; % 5; P1问题中; PCG 0.05
% 
% 增大beta_1: 增强结果变暗，抑制过增强；
% 因为与be管的P1更接近于真实的反射分量，不会过曝光；
% 而与beta相关的P倾向于过曝光

%% 由模型可得，增大beta_1会使得P1和R接近；实验结果符合模型的预期分析。
% opts_my.sigma_2 = 0.000100;  %子问题P的： CBM3D: 100 ; 参考GLON的sigma2参数设置(Refer to GLON parameter Settings)  100
% opts_my.sigma_2 = sqrt(opts_my.lambda_4/(opts_my.beta+rho_6));  %子问题P的： CBM3D: 100 ; 参考GLON的sigma2参数设置(Refer to GLON parameter Settings)  100

%% 4) R、epsilon和J中的相关正则化参数 和 CBM3D函数中的滤波参数(sigma_1)
opts_my.theta = 0.13;    % 1 对应GLON论文中的beta1: 100; 参考GLON的参数设置(Refer to GLON parameter Settings)
%%%
% opts_my.sigma_1 = 0.00004;  %FFDnet: 0.04; 参考GLON的参数设置(Refer to GLON parameter Settings) 0.04;
% % opts_my.sigma_1 = sqrt(opts_my.lambda_3/opts_my.theta);  %FFDnet: epsilon 0.04; 参考GLON的参数设置(Refer to GLON parameter Settings) 0.04;
% % sigma_1需要在求解R的内循环中进行赋值和更新，因为sigma_1和theta相关。



dataset_test = 3;
% 1: LOL-v1;  2: LOL-v2;  3: PG660; 4: PG660_50
% 5：LIME,10;    6: MEF,17;  7: DICM: 69;  8: VV, 24;
% 9: NEP, 85;    10: 有问题的图像
switch dataset_test
    case 1
        gamma = 2.6;
        path = 'Data\LOL-v1\low\';
        method_name = '_GLON_';
        Outputdir = ['Results_EGSR_GLON_LOL-v1_', case_name, '\'];
        files = dir([path, '*.png']);
        dataset_name = '_LOL_v1_';
    case 2
        gamma = 2.6;
%         path = 'Data\LOL-v2\Real_captured\Test\Low_红点\';
        path = 'Data\LOL-v2\Real_captured\Test\Low\';
        method_name = '_GLON_';
        Outputdir = ['Results_EGSR_LOL-v2_', case_name, '\'];
        files = dir([path, '*.png']);
        files_name = dir(fullfile(path, '*.png'));

        dataset_name = '_LOL_v2_';
    case 3
        gamma = 2.2;
        path = 'Data\PG660_660\';

        method_name = '_EGSR_';
        Outputdir = ['Results_EGSR_660_', case_name, '\'];
        files = dir([path, '*.jpg']);
        dataset_name = '_PG660_';
    case 4
        gamma = 2.2;
        path = 'Data\PG660_50\';
        Outputdir = ['Results_Retinex_GLON_PG_50_2.2_', case_name, '\'];
        files = dir([path, '*.jpg']);
%         files = dir([path, '*.png']);
        dataset_name = '_PG50_';
    case 5
        gamma = 2.2;
        path = 'Data\LIME\';
        Outputdir = ['Results_Retinex_GLON_LIME_2.2-4.4', case_name, '\'];
        files = dir([path, '*.jpg']);
        dataset_name = '_LIME_';
    case 6
        gamma = 2.2;
        path = 'Data\MEF\';
        Outputdir = ['Results_Retinex_GLON_MEF_2.2-4.4', case_name, '\'];
        files = dir([path, '*.png']);
        dataset_name = '_MEF_';

    case 7
        gamma = 2.2;
        path = 'Data\DICM_png_69\';
        Outputdir = ['Results_Retinex_GLON_DICM_2.2-4.4', case_name, '\'];
        files = dir([path, '*.png']);
        dataset_name = '_DICM69_';

    case 8
        gamma = 2.2;
        path = 'Data\VV_rename_png\';
        Outputdir = ['Results_Retinex_GLON_VV_2.2-4.4', case_name, '\'];
        files = dir([path, '*.png']);
        dataset_name = '_VV24_';

    case 9
        gamma = 2.2;
        path = 'Data\NPE_85_png\';
        Outputdir = ['Results_Retinex_GLON_NPE_2.2-4.4', case_name, '\'];
        files = dir([path, '*.png']);
        dataset_name = '_NPE85_';
    case 10
        gamma = 2.2;
        path = 'Data\有问题的图像\';
        Outputdir = ['Results_Retinex_GLON_有问题的图像_2.2-4.4', case_name, '\'];
        files = dir([path, '*.png']);
        dataset_name = '_有问题的图像_';
    case 11
        gamma = 2.6;
        path = 'Data\Input\';
        method_name = '_GLON_';
        Outputdir = ['Results_Retinex_GLON_NTIRE2024_2.2-3.2_', case_name, '\'];
        files = dir([path, '*.png']);
        dataset_name = '_NTIRE2024_';

end

opts_my.save_k_th = 0;
opts_my.Outputdir = Outputdir;

im_num = length(files);


time_Retinex_GLON = zeros(im_num, 1);
opts_metric = [];
opts_metric.NIQE_arry = zeros(1,im_num); opts_metric.ILNIQE_arry = zeros(1,im_num); opts_metric.NIQE_MATLAB_arry = zeros(1,im_num);
opts_metric.BTMQI_S_arry = zeros(1,im_num); opts_metric.LOE_S_arry = zeros(1,im_num); opts_metric.BRISQUE_S_arry = zeros(1,im_num);
opts_metric.CEIQ_B_arry = zeros(1,im_num); opts_metric.NIQMC_B_arry = zeros(1,im_num); opts_metric.VIF_B_arry = zeros(1,im_num);
opts_metric.ARISMC_1_B_arry = zeros(1,im_num); opts_metric.ARISMC_2_B_arry = zeros(1,im_num); opts_metric.DIIVINE_B_arry = zeros(1,im_num);

if ~exist(Outputdir, "dir")
    mkdir(Outputdir)
end

%% 5) 模型求解（Model solving）
PSNR_arry = zeros(im_num,1);
SSIM_arry = zeros(im_num,1);

for i_th = 1:im_num
    
    
    if opts_my.debug == 1
        if i_th <= test_th        
            continue;
    %         break;
        end
    
        if i_th >= (test_th+2)
    %         continue;
            break;
        end
    end


    time_start = tic;
    %% 原始RGB图像数据的加载 (Loading of RGB image data)
    % 正在处理660张图像中的第8张图像 (Image 8 out of 660 images being processed)
    fprintf('********************Image %d-th out of %d images being processed: ********************\n', i_th, im_num);
    img_name = files(i_th).name;
    % 正在处理的图像的名称
    fprintf('The name of the image being processed: %s \n', img_name);

%     Input_img_RGB = im2double(imread([path img_name]));  % GLON paper
    Input_img_RGB = double(imread([path img_name]));  % GLON paper
%     Input_img_RGB = min(255, max(Input_img_RGB, 0));

    %% 将RGB图像进行VDT(Visual data tensorization)转化 (Perform VDT(Visual data tensorization) conversion on RGB images)
    % 1) 先进行高和宽维度的扩充，使得高和宽分解的质因数的个数相同 (First, the dimensions of height and width are expanded so that the number of prime factors of height and width decomposition is the same)
    [Input_img_RGB_dila, opt_factor] = image_dilation_ywp(Input_img_RGB);
    nway_dila = size(Input_img_RGB_dila);
    % 2) VDT操作
    [Input_img_RGB_dila_VDT, factor_H_W_C, permute_nway] = image2vdt256_ywp(Input_img_RGB_dila, opt_factor);
    Nway_VDT = size(Input_img_RGB_dila_VDT);

    %% 模型求解（Model solving）
    [L, R_RGB] = BT_TT_L_NL_solve_L_first_L_and_P_update_3times(Input_img_RGB_dila,Input_img_RGB_dila_VDT, Nway_VDT, nway_dila, opts_my,opt_factor,factor_H_W_C,...
        files(i_th), methodname, dataset_name, case_name);
   
    %% L和R的裁剪
    L =     L(1:opt_factor.H_ini, 1:opt_factor.W_ini,:);
    R_RGB = R_RGB(1:opt_factor.H_ini, 1:opt_factor.W_ini,:);

    for k_cha = 1:3
        L(:,:,k_cha)     = min(max(    L(:,:,k_cha),0),max(max(    L(:,:,k_cha))));
        R_RGB(:,:,k_cha) = min(max(R_RGB(:,:,k_cha),0),max(max(R_RGB(:,:,k_cha))));
    end

%     R_RGB(R_RGB<0)=0;  % 对消除溢出没有效果了

    fprintf('最终L的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(L(:)), min(L(:)),class(L));
    fprintf('最终R_RGB的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(R_RGB(:)), min(R_RGB(:)),class(R_RGB));


    %% 数值溢出处理
%     max_intensity = 1;
%     L = min( max(L, 0), max_intensity);
%     R_RGB = min( max(R_RGB, 0), max_intensity);

%% gamma校正方式1
% % % % % % % % % % L_gamma_ywp(R_RGB,L,files(i_th), Outputdir,methodname,dataset_name,case_name)
% out_rec = L_gamma_255_ywp_255(R_RGB,L,files(i_th), Outputdir,methodname,dataset_name,case_name,gamma_end);
out_rec = L_gamma_255_ywp_max(R_RGB,L,files(i_th), Outputdir,methodname,dataset_name,case_name,gamma_end,opts_my);

% metric_ywp(uint8(255*out_rec),uint8(Input_img_RGB))
gamma_test = 3;
opts_metric = metric_function_ywp(opts_metric, i_th, im_num,uint8(255*out_rec), uint8(Input_img_RGB), Outputdir,dataset_name,method_name,case_name,gamma_test);

    if (dataset_test==1 || dataset_test==2) && (opts_my.psnr_ssiim_dis == 1)
        % 参考图像应该是normal light
        PSNR_index  = psnr(uint8(255*out_rec),Input_img_RGB);
        PSNR_arry(i_th,1) = PSNR_index;
        SSIM_index  = ssim(uint8(255*out_rec),Input_img_RGB);
        SSIM_arry(i_th,1) = SSIM_index;
    end

    %% 时间记录（Time recording）
    time_Retinex_GLON(i_th,1) = toc(time_start);
    time_single = time_Retinex_GLON(i_th,1)


    %     figure('Name','L & R '),
%     subplot(141),imshow(L,[]),title('L');
%     subplot(142),imshow(uint8(255*L),[]),title('L uint8');
%     subplot(143),imshow(R_RGB),title('R');
%     subplot(144),imshow(uint8(255*R_RGB)),title('R uint8');

    fprintf('\n \n');


end

%% 时间记录保存（Time recording）
save([Outputdir, 'time_Retinex_GLON.mat'],'time_Retinex_GLON');

delete(gcp('nocreate'))










