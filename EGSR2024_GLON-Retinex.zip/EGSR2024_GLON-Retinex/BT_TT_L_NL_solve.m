function [L, R_RGB] = BT_TT_L_NL_solve(Input_img_RGB_dila,Input_img_RGB_dila_VDT, Nway_VDT, nway_dila, opts_my,opt_factor,factor_H_W_C)

%%  模型参数的初始化
maxit = opts_my.maxit;
tol = opts_my.tol;
% rho
rho_GLON = opts_my.rho_GLON;

% Tensor train rank 的权重
alpha = weightTC(Nway_VDT);
opts_my.alpha = alpha;

%% 
N = length(Nway_VDT);  % N: VDT后高维张量的维度
% 1) 照度分量L的初始化
L = Input_img_RGB_dila;
L_0 = L;

% 2) R的初始化

% R = initialization_M(Nway_VDT);   % GLON paper

R0_VDT = Input_img_RGB_dila_VDT;     % reshape后得到R^t (R_Temp: R^t的矩阵展开形式)
R0_RGB = Input_img_RGB_dila;

% R0_VDT = double(ones(Nway_VDT));
% R0_RGB = double(ones(size(Input_img_RGB_dila)));

% P_RGB_0  = ones(dim_RGB);    % P同时作为P^(t)和P^(t+1)
% P1_RGB_0 = ones(dim_RGB);    
P_RGB_0  = R0_RGB;    % P同时作为P^(t)和P^(t+1)
P1_RGB_0 = R0_RGB;   


[H,W,c] = size(R0_RGB);
dim_RGB = size(R0_RGB);

fprintf('正在跑此程序： BT_TT_L_NL_solve  \n')

%% lambda
% lambda_1 = opts_my.lambda_1;
lambda_2 = opts_my.lambda_2;
% lambda_3 = opts_my.lambda_3;  % sigma_1
lambda_4 = opts_my.lambda_4;  % sigma_2

%% Plug-and-play (FFDnet和CBM3D)中的参数
% sigma_2 = opts_my.sigma_2;

%% 辅助变量P、P1相关的正则化参数
beta = opts_my.beta;
beta_1 = opts_my.beta_1;

%% 待求解变量的初始化
% 1) (Xi, Yi)的初始化
% X和Y是R展开矩阵的满秩分解的矩阵
seq_len = opt_factor.length_factor_1;   % 质因数分解的长度
ranktube = ranktube_ywp(seq_len);
[X,Y] = initialMatrix(N,Nway_VDT,ranktube);  % save X.mat X  % save Y.mat Y
X0 = X; 
Y0 = Y;



%% canonical matricization
% 计算第k个模式展开下的矩阵维度
dimL = zeros(1,N-1);
dimR = zeros(1,N-1);
IL = 1;
for k = 1:N-1
    dimL(k) = IL*Nway_VDT(k);
    dimR(k) = prod(Nway_VDT)/dimL(k);
    IL = dimL(k);
end

%% rannk
if seq_len>=5
    %% GLON paper
    % max_rank = [30 50 50 30];
    % max_rank是X{i}和Y{i}的中间矩阵的最大秩，不包含前2个和后2个
    max_rank = max_rank_ywp(opt_factor);
    rank_inc = 5;
    
    %% 仅对中间的X和Y的秩进行更新
    % seq_len + 1 >=6
    for i=1:(seq_len+1-2-3)  % seq_len+1表示VDT后高阶张量的阶数 % 1) 如果质因数分解的长度大于等于5
        MM{i}=reshape(X0{i+2}*Y0{i+2},Nway_VDT); 
        MMi = MM{i};
        resrank{i}=norm(R0_VDT(:)- MMi(:));
    end
else % 2) 如果质因数分解的长度小于5
    max_rank = max_rank_ywp(opt_factor);
    rank_inc = 5;
    for i = 1:(seq_len)   % seq_len + 1 <=5
        MM{i} = reshape(X0{i}*Y0{i},Nway_VDT);
        MMi   = MM{i};
        resrank{i} = norm(R0_VDT(:)-MMi(:));
    end
end

%% 求解L的参数的初始化
sigma_L = 3.0;      
sigma_iter = sigma_L;
dec=2;

%% 迭代初始化
k = 1;
relerr_R_outloop = [];
relerr_R_outloop(1) = 1;
relerr_L = [];
relerr_L(1) = 1;


%% 迭代求解
while relerr_R_outloop(k) > tol
    k = k + 1;
    fprintf('\n\n **********************外部循环迭代次数: k = %d **********************: \n', k-1);

    opts_my.rho_1 = rho_GLON*100;    % L
    opts_my.rho_2 = rho_GLON/100;    % R
    %% 减小rho_2有助于使得R的分布达到预期
    opts_my.rho_3 = rho_GLON*10;    % X  
    opts_my.rho_4 = rho_GLON/10;    % Y
    opts_my.rho_5 = rho_GLON;    % P1
    opts_my.rho_6 = rho_GLON*2;    % P
    %% 小的rho_6使得CBM3D的平滑效果显著
    rho_1 = opts_my.rho_1; rho_2 = opts_my.rho_2; rho_3 = opts_my.rho_3;
    rho_4 = opts_my.rho_4; rho_5 = opts_my.rho_5; rho_6 = opts_my.rho_6;

    opts_my.sigma_2 = sqrt(lambda_4/(beta+rho_6));  %子问题P的： CBM3D: 100 ; 参考GLON的sigma2参数设置(Refer to GLON parameter Settings)  100
    sigma_2 = opts_my.sigma_2;
    
    %% 1) Update (Xi, Yi) 直接采用伪逆求解的，可以换成PCG(不行，除了伪逆的部分，其他的为矩阵)
    fprintf(' ********************** 1) Updating Xi, Yi: ...... \n')
    for n = 1:N-1
        R_Temp = reshape(R0_VDT,[dimL(n), dimR(n)]);    % canonical matricization后的矩阵
        X{n} = ( lambda_2*alpha(n)*R_Temp*Y0{n}' + rho_3*X0{n} )...
            * pinv( lambda_2*alpha(n)*Y0{n}*Y0{n}' + rho_3*eye( size(Y0{n}*Y0{n}') ) );
        Y{n} = pinv( lambda_2*alpha(n)*X{n}'*X{n} + rho_4*eye( size(X{n}'*X{n}) ) )...
            * ( lambda_2*alpha(n)*X{n}'*R_Temp + rho_4*Y0{n} );
    end
    
    %% 2) Update P : CBM3D
    Input_CBM3D = (beta*R0_RGB + rho_6*P_RGB_0) / (beta + rho_6); 
    %% 由上述求解公式可以看出：
    %% 减小beta和rho_6，有助于使得P的分布更高进R，远离输入图像的分布。
    %% 但是目前，经过CBM3D平滑后的P还无法传递到R

    % 此处Input_CBM3D的最大值，随着外循环的增加而增加；最大值会超过1
    fprintf('1: Input_CBM3D 初始时刻的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(Input_CBM3D(:)), min(Input_CBM3D(:)),class(Input_CBM3D));
    B = zeros(1,c);
    for i= 1:c
        Temp2 = Input_CBM3D(:,:,i);
        B(i) = max(Temp2(:));
        Input_CBM3D(:,:,i) =  Temp2/B(i);
    end
    fprintf('2: Input_CBM3D 分通道除以最大值的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(Input_CBM3D(:)), min(Input_CBM3D(:)),class(Input_CBM3D));

    max_in2 = max(Input_CBM3D(:));min_in2 = min(Input_CBM3D(:));
    Input_CBM3D = (Input_CBM3D-min_in2)/(max_in2-min_in2+eps);
    sigma_2_normli = 255*sigma_2/(max_in2-min_in2+eps)
%     sigma_2_normli = sigma_2
%     fprintf('3: Input_CBM3D 归一化0~1后的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(Input_CBM3D(:)), min(Input_CBM3D(:)),class(Input_CBM3D));
    fprintf('3: CBM3D输入的Input_CBM3D 归一化0~1后的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(Input_CBM3D(:)), min(Input_CBM3D(:)),class(Input_CBM3D));

    fprintf(' ********************** 2) Updating P: using CBM3D...... \n')
    [~, P_RGB] = CBM3D(0, Input_CBM3D, sigma_2_normli);

    
    
    fprintf('1：P_RGB 归一化后的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(P_RGB(:)), min(P_RGB(:)),class(P_RGB));

               
%     P_RGB(P_RGB<0)=0;P_RGB(P_RGB>1)=1;
    P_RGB = P_RGB*(max_in2-min_in2)+min_in2;  

    fprintf('2：P_RGB 逆归一化后的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(P_RGB(:)), min(P_RGB(:)),class(P_RGB));
    for i= 1:c
        P_RGB(:,:,i) =   B(i)*P_RGB(:,:,i);
    end
    figure('Name','外循环的P：CBM3D'),imshow(P_RGB)
    fprintf('3：P_RGB 逆归一化后的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(P_RGB(:)), min(P_RGB(:)),class(P_RGB));
        
    %% 3) Update P1 ： 采用PCG的方法，而不是伪逆的方法求解：
    fprintf(' ********************** 3) Updating P1: using pcg...... \n')
    [P1_RGB] = Reinex_GLON_P1_solve(L_0, Input_img_RGB_dila,beta_1,R0_RGB,rho_5,P1_RGB_0,H, W, c);

    %% 4) Update (R, epsilon, J)
    fprintf(' ********************** 4) Updating R,  Eimg, J: using ADMM...... \n')
    [R_RGB,relerr_R] = Reinex_GLON_R_solve(Input_img_RGB_dila, L,R0_VDT,R0_RGB, X,Y,P_RGB,P1_RGB,nway_dila,Nway_VDT,N,opts_my,opt_factor,factor_H_W_C);
%     [R_RGB,relerr_R] = Reinex_GLON_R_solve_none_normalization(R0_VDT, X,Y,P_RGB,P1_RGB,nway_dila,Nway_VDT,N,opts_my,opt_factor,factor_H_W_C);
    fprintf('1: R_RGB的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(R_RGB(:)), min(R_RGB(:)),class(R_RGB));
    % R_RGB要不要更新，类比GLON论文中的Mimg。
    figure('Name','外循环的  R - R_RGB'),imshow(R_RGB)
%     [R0_VDT, ~, ~] = image2vdt256_ywp(R_RGB, opt_factor);
    
    %% 5) Update L
    fprintf(' ********************** 5) Updating L...... \n')
    L =    solve_L_BT(Input_img_RGB_dila,L_0,P1_RGB, opts_my,sigma_iter);
    fprintf('1: L的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(L(:)), min(L(:)),class(L));
    sigma_iter = sigma_iter / dec;
    if sigma_iter < 0.5
        sigma_iter = 0.5;
    end  

    if k==2
        R_RGB = Input_img_RGB_dila./ L;
    end

    relerr_R_outloop(k) = abs(norm(R_RGB(:)-R0_RGB(:)) / norm(R0_RGB(:)));
    relerr_L(k) = abs(norm(L(:)-L_0(:)) / norm(L_0(:)));
    fprintf(' **********************外循环第k=%d次迭代R的误差为:%f \n', k-1, relerr_R_outloop(k));
    fprintf(' **********************外循环第k=%d次迭代L的误差为:%f \n', k-1, relerr_L(k));
    fprintf(' **********************外循环第%d 次迭代rho_GLON的值为: %f \n：', k-1, rho_GLON);

    
    %% 更新已经求解的变量，作为变量在第t次迭代中的值，以便在第t+1次迭代使用
    % 1) 更新(X0, Y0)
    X0 = X;
    Y0 = Y;
    P_RGB_0 = P_RGB;
    P1_RGB_0 = P1_RGB;
    [R0_VDT, ~, ~] = image2vdt256_ywp(R_RGB, opt_factor);
    R0_RGB = R_RGB;
    L_0 = L;
        
    %% 迭代停止的准则的判断 (Judgment of iteration stop criteria)
    if k > maxit ||  relerr_R_outloop(k) < tol  
        break 
    end
    rho_GLON = 1.2 * rho_GLON;


%     if k == 25
%         rho_GLON = 1.5 * rho_GLON;
%     end
%     
%     if k == 30
%         rho_GLON = 1.5 * rho_GLON;
%     end
%     
%     if k == 35
%         rho_GLON = 1.5 * rho_GLON;
%     end
%     
%     if k >40
%         rho_GLON = 1.2 * rho_GLON;
%     end

    beta=beta*1.2;
    %% update Rank  
    if seq_len >= 5
        for i=1:(seq_len+1-2-3)  % seq_lend大于等于5才成立
            resold{i}=resrank{i};
            MM{i}=reshape(X{i+2}*Y{i+2},Nway_VDT); 
            MMi = MM{i};
%             MMi=R0_VDT;
            resrank{i}=norm(R0_VDT(:)-MMi(:));
            ifrank{i} = abs(1-resrank{i}/resold{i});
                nowrank = now_rank_ywp(X, opt_factor);
            if ifrank{i}<0.01 && nowrank(i)<max_rank(i)
                [X{i+2},Y{i+2}]=rank_inc_adaptive(X{i+2},Y{i+2},rank_inc);
            end
        end
    else
        for i = 1:(seq_len)
            resold{i} = resrank{i};
            MM{i} = reshape(X{i}*Y{i}, Nway_VDT);
            MMi  = MM{i};
%             MMi  = R0_VDT;
            resrank{i} = norm(R0_VDT(:)-MMi(:));
            ifrank{i} = abs(1-resrank{i}/resold{i});
            nowrank = now_rank_ywp(X, opt_factor);
            if ifrank{i}<0.01 && nowrank(i)<max_rank(i)
                [X{i}, Y{i}] = rank_inc_adaptive(X{i}, Y{i}, rank_inc);
            end
        end
    end

end

iter_k = k;
% 反射分量的误差(外层循环中)
figure,plot(1:iter_k-1,relerr_R_outloop(2:iter_k)), legend('error of R');
% hold on
figure,plot(1:iter_k-1,relerr_L(2:iter_k)), legend('error of L');

end


function [A,X]=rank_inc_adaptive(A,X,rank_inc)
    % increase the estimated rank
    for ii = 1:rank_inc
        rdnx = rand(size(X,1),1);
        rdna = rand(1,size(A,2));
        X = [X,rdnx];
        A = [A;rdna];
    end
end

%% (Xi, Yi)的初始化函数
function [X0,Y0] = initialMatrix(N,Nway,ranktube)
X0 = cell(1,N-1);Y0 = cell(1,N-1);
dimL = zeros(1,N-1);
dimR = zeros(1,N-1);
IL = 1;
    for k = 1:N-1
        dimL(k) = IL*Nway(k);
        dimR(k) = prod(Nway)/dimL(k);
        %
        X0{k} = randn(dimL(k),ranktube(k));
        Y0{k} = randn(ranktube(k),dimR(k));
        %uniform distribution on the unit sphere
        X0{k} = bsxfun(@rdivide,X0{k},sqrt(sum(X0{k}.^2,1)));
        Y0{k} = bsxfun(@rdivide,Y0{k},sqrt(sum(Y0{k}.^2,2)));
        %
        IL = dimL(k);
    end
end