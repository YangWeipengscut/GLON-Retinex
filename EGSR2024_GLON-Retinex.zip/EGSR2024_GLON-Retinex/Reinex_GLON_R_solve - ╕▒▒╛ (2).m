



function [R_RGB,relerr_R_innerloop] = Reinex_GLON_R_solve(Input_img_RGB_dila, L,R0_VDT,R0_RGB,X,Y,P,P1,nway_dila,Nway_VDT,N,opts_my,opt_factor,factor_nway)

%% 参数初始化
global sigmas
alpha = opts_my.alpha;

theta = opts_my.theta;
% sigma_1 = opts_my.sigma_1;
% % sigma_1 = sqrt(opts_my.lambda_3/theta);

rho_2 = opts_my.rho_2;
beta = opts_my.beta;
beta_1 = opts_my.beta_1;
lambda_2 = opts_my.lambda_2;
% tol = opts_my.tol;
tol = 3*1e-8;

%% 反射分量的初始化和VDT相关操作

% R_VDT  =  R0_VDT;
R_RGB = R0_RGB;

% R_RGB = ones(size(R0_RGB));
%%
% R_RGB = Input_img_RGB_dila./ L;  % 这个初始化会导致经过CBM3D平滑后的P很难传递到R
% 因为Input_img_RGB_dila是不变的，L基本不变，会导致每次内循环更新R和Eimg时，噪声会重新残留到R中。
%% 




[H,W,c] = size(R0_RGB);
fprintf('正在跑此程序： Reinex_GLON_R_solve  \n')
%% 辅助变量（Eimg）和乘子数(J)初始化
Eimg = R0_RGB;
J = zeros(size(Eimg));

%% GPU相关设置
% FFDnet parameter
useGPU      = 1;
% FFDnet parameter
if c == 3
    load(fullfile('FFDNet_Clip_color.mat'));
else
    load(fullfile('FFDNet_Clip_gray.mat'));
end
net = vl_simplenn_tidy(net);
if useGPU
    net = vl_simplenn_move(net, 'gpu') ;
end



inner_maxit = 20;   % 5
for r = 1:inner_maxit
%     fprintf('内部循环的次数: r =  %d/%d) \n', r, inner_maxit);
    R_last = R_RGB;
    
    %% 1) Update epsilon
    input0 = R_RGB - J/theta;

    %% 分通道除以最大值
    A = zeros(1,c);
    for i= 1:c
        Temp = input0 (:,:,i);
        A(i) = max(Temp(:));
        input0(:,:,i) =  Temp /A(i);
    end
            
    if c==3
        input = input0;
    else
        input = unorigami(input0,[H W c]);
    end
    
%     input = input0;

    fprintf('1：epsilon的input分通道除以最大值后的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(input(:)), min(input(:)),class(input));

    input = single(input); %
    if c==3
        if mod(H,2)==1
            input = cat(1,input, input(end,:,:)) ;
        end
        if mod(W,2)==1
            input = cat(2,input, input(:,end,:)) ;
        end
    else
        if mod(H,2)==1
            input = cat(1,input, input(end,:)) ;
        end
        if mod(W,2)==1
            input = cat(2,input, input(:,end)) ;
        end
    end

    if useGPU
        input = gpuArray(input);
    end
    max_in = max(input(:));min_in = min(input(:));
    input = (input-min_in)/(max_in-min_in);
    fprintf('2：epsilon的input归一化后的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(input(:)), min(input(:)),class(input));

    % 全局变量
    sigma_1 = sqrt(opts_my.lambda_3/theta);
%     sigmas = 0.001*sigma_1/(max_in-min_in)
    sigmas = 0.001*sigma_1

    res    = vl_simplenn(net,input,[],[],'conserveMemory',true,'mode','test');
    output = res(end).x;
%     fprintf('1：output的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(output(:)), min(output(:)),class(output));
        
    output(output<0)=0;output(output>1)=1;
    output = output*(max_in-min_in)+min_in;
%     fprintf('2：output的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(output(:)), min(output(:)),class(output));

    if c==3
        if mod(H,2)==1
            output = output(1:end-1,:,:);
        end
        if mod(W,2)==1
            output = output(:,1:end-1,:);
        end
    else
        if mod(H,2)==1
            output = output(1:end-1,:);
        end
        if mod(W,2)==1
            output = output(:,1:end-1);
        end
    end

    if useGPU
        output = gather(output);
    end
    
    if c==3
        Eimg = double(output);   
    else
        Eimg = origami(double(output),[H W c]);
    end
    
    for i= 1:c
        Eimg(:,:,i) =   A(i)*Eimg(:,:,i);
    end

%     for i= 1:c
%         temp_E = Eimg(:,:,i);
%         min_E = min(temp_E(:));
%         Eimg(:,:,i) =   Eimg(:,:,i) - min_E;
%     end
    
    if opts_my.im_show == 1
        figure('Name','内循环的  Eimg'),imshow(Eimg)
    end   


    fprintf('3：epsilon对应的Eimg的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(Eimg(:)), min(Eimg(:)),class(Eimg));

    %% 2） Update R_RGB
    % 右边的矩阵
    temp1_VDT = image2vdt256_ywp(theta*Eimg+J, opt_factor);  % 第2、3项
    P1_VDT= beta_1*image2vdt256_ywp(P1, opt_factor); % 第4项
    P_VDT= beta*image2vdt256_ywp(P, opt_factor);    % 第5项
    temp_R_VDT = rho_2*R0_VDT; % 第6项
    
    temp = temp1_VDT + P1_VDT + P_VDT + temp_R_VDT;
    % temp累加第1项得到右边的全部
    for n = 1:N-1
        temp = temp + lambda_2*alpha(n)*reshape(X{n}*Y{n},Nway_VDT);
    end
    % 左边个参数之和的常量； (lambda_2 + theta + beta_1 + beta + rho_2)
    %% 求解R的VDT形式
    
    R_VDT = temp/(lambda_2 + theta + beta_1 + beta + rho_2);

    %% 和GLON的代码不同，该子函数返回RGB形式的反射分量。
    R_RGB  =  vdt2image_ywp(R_VDT, factor_nway, nway_dila, opt_factor);
    fprintf('2: Eimg后的 R_RGB的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(R_RGB(:)), min(R_RGB(:)),class(R_RGB));
  
    %% Update 乘子数 和 正则化参数
    J = J + theta * (Eimg - R_RGB);
    theta = theta * 1.2;
        
    %% 迭代停止准则
    relerr_R_innerloop(r) = abs(norm(R_RGB(:)-R_last(:)) / norm(R_last(:)));
    fprintf('********************************************求解R的内循环第r = %d次迭代的误差为:%f \n\n', r, relerr_R_innerloop(r));
    if relerr_R_innerloop(r)< tol
        break
    end
    

end
figure,plot(1:r,relerr_R_innerloop(1:r)), legend('内循环中的error of R');


end