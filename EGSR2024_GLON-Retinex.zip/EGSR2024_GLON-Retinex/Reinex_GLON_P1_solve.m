

function [P1_RGB] = Reinex_GLON_P1_solve(L,   Input_img_RGB_dila,beta_1,R0_RGB, rho_5,P1_RGB_0,H, W, c,opts_my)
% 方程的右边
    temp_P1_right = 2*L.*Input_img_RGB_dila + beta_1*R0_RGB + rho_5 * P1_RGB_0;
    
    % 方程的左边
    L_square = 2*L.^2;
    L_square_diag = spdiags(L_square(:), 0, W*H*c,W*H*c);
    temp_P1_left = L_square_diag + (beta_1 + rho_5)*speye( W*H*c,  W*H*c);
   
    linear_method = 'pcg';
    switch linear_method
        case 'pcg'
            IC_M = ichol(temp_P1_left, struct('michol','on')); %  IC_M: ichol matrix
            [dst, ~] = pcg(temp_P1_left, temp_P1_right(:), 0.01,40, IC_M, IC_M');
        case 'minres'
            [dst, ~] = minres(temp_P1_left, temp_P1_right(:), 0.01, 40);
    end 
    
    P1_RGB = reshape(dst, H, W, c);   % P1 ^(t+1)

    if opts_my.text_show == 1
        fprintf('1：P1_RGB的最大值为: %.2f, 最小值为: %.2f，数据类型为：%s \n', max(P1_RGB(:)), min(P1_RGB(:)),class(P1_RGB));
    end
    
    
    if opts_my.im_show == 1
        figure('Name','外循环的 P1： PCG'),imshow(P1_RGB)
    end

end